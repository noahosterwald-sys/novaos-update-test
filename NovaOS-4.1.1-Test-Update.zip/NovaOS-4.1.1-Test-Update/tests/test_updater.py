"""NovaOS 4.1 update engine tests; no network, apt, polkit or disk installation."""
from __future__ import annotations
import io
import shutil
import subprocess
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'updater'))
import core
import update_center
import apply_update
from test_novaos import nova


def make_zip(path, version='4.2', prefix='NovaOS-4.2-Komplett/', extra=None):
    extra = extra or {}
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for member in core.REQUIRED:
            zf.writestr(prefix + member, version + '\n' if member == 'VERSION' else 'demo')
        for member, contents in extra.items():
            zf.writestr(member, contents)
    return path


class UpdateEngineTests(unittest.TestCase):
    def test_version_comparison(self):
        self.assertTrue(core.is_newer('4.1', '4.0'))
        self.assertTrue(core.is_newer('4.10', '4.9'))
        self.assertFalse(core.is_newer('4.1', '4.1'))
        self.assertFalse(core.is_newer('4.0', '4.1'))
        for version in ('4.1; reboot', 'v4.2', '../4', '4.1.2.3', ''):
            with self.subTest(version=version), self.assertRaises(core.UpdateError):
                core.version_tuple(version)

    def test_existing_installation_detected_without_version_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self.assertEqual(core.installed_version(root), '4.1')
            (root / 'backend').mkdir()
            (root / 'backend/server.py').write_text('demo')
            self.assertEqual(core.installed_version(root), '4.0')
            (root / 'VERSION').write_text('4.2\n')
            self.assertEqual(core.installed_version(root), '4.2')

    def test_manifest_https_sha_and_length_required(self):
        good = {'version': '4.2', 'zip_url': 'https://example.org/release.zip', 'sha256': 'a'*64, 'notes': 'Neue Funktionen'}
        self.assertEqual(core.validate_manifest(good)['version'], '4.2')
        for change in ({'zip_url': 'http://example.org/release.zip'},
                       {'zip_url': 'https://localhost/release.zip'},
                       {'sha256': 'xyz'}, {'version': 'v4.2'},
                       {'notes': ['unzulässig']}):
            bad = {**good, **change}
            with self.subTest(bad=change), self.assertRaises(core.UpdateError):
                core.validate_manifest(bad)

    def test_zip_nested_and_flat(self):
        with tempfile.TemporaryDirectory() as tmp:
            z = make_zip(Path(tmp)/'nested.zip')
            self.assertEqual(core.inspect_zip(z), ('4.2', 'NovaOS-4.2-Komplett/'))
            z = make_zip(Path(tmp)/'flat.zip', prefix='')
            self.assertEqual(core.inspect_zip(z), ('4.2', ''))

    def test_zip_traversal_and_unsafe_symlinks_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            z = make_zip(Path(tmp)/'bad.zip', extra={'NovaOS-4.2-Komplett/../../hack': 'boom'})
            with self.assertRaises(core.UpdateError): core.inspect_zip(z)
            z = make_zip(Path(tmp)/'bad2.zip', extra={'NovaOS-4.2-Komplett/a\\b': 'boom'})
            with self.assertRaises(core.UpdateError): core.inspect_zip(z)
            z = Path(tmp)/'bad3.zip'
            with zipfile.ZipFile(z,'w') as f:
                for member in core.REQUIRED:
                    f.writestr('NovaOS-4.2-Komplett/'+member, '4.2\n' if member == 'VERSION' else 'demo')
                info = zipfile.ZipInfo('NovaOS-4.2-Komplett/malicious-link')
                info.create_system=3
                info.external_attr=(0o120777 << 16)
                f.writestr(info, '/etc/passwd')
            with self.assertRaises(core.UpdateError): core.inspect_zip(z)

    def test_zip_missing_required_or_duplicate_member_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            z = Path(tmp)/'bad.zip'
            with zipfile.ZipFile(z,'w') as f:
                f.writestr('VERSION','4.2\n')
            with self.assertRaises(core.UpdateError):core.inspect_zip(z)
            z = make_zip(Path(tmp)/'duplicated.zip', extra={'NovaOS-4.2-Komplett/VERSION': '4.3\n'})
            with self.assertRaises(core.UpdateError):core.inspect_zip(z)

    def test_checksums_and_config_permissions(self):
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/'text'
            f.write_bytes(b'abcd')
            self.assertEqual(core.sha256_file(f),'88d4266fd4e6338d13b845fcf289579d209c897823b9217da3e161936f031589')
            config=Path(tmp)/'config.json'
            core.save_config('https://example.com/release.json',config)
            self.assertEqual(core.load_config(config)['manifest_url'],'https://example.com/release.json')
            self.assertEqual(config.stat().st_mode & 0o777, 0o600)
            with self.assertRaises(core.UpdateError):core.save_config('file:///etc/shadow',config)

    def test_manual_updates_require_confirmation_and_local_pc(self):
        with patch.object(update_center,'dialog',return_value=''):
            self.assertTrue(update_center.confirm('Bist du sicher?'))
        with patch.object(update_center,'dialog',return_value=None):
            self.assertFalse(update_center.confirm('Bist du sicher?'))
        with self.assertRaises(ValueError):
            nova.execute_action('app',{'id':'nova_update'}, local=False)
        with patch.object(nova,'open_app',return_value='Gestartet') as run:
            self.assertEqual(nova.execute_action('app',{'id':'nova_update'}, local=True),'Gestartet')
            run.assert_called_once_with('nova_update')

    def test_privileged_install_simulated_success_and_backup(self):
        # Runs against a temporary pseudo-/opt tree. No actual packages, root,
        # system configurations or user files are changed.
        with tempfile.TemporaryDirectory() as tmp:
            temp = Path(tmp)
            installed = temp / 'novaos'
            (installed/'backend').mkdir(parents=True)
            (installed/'backend/server.py').write_text('old')
            (installed/'VERSION').write_text('4.0\n')
            archive = make_zip(temp/'new.zip', version='4.2')
            digest = core.sha256_file(archive)
            def mock_install(args, check=False, **kwargs):
                source = Path(args[1]).parent.parent
                for member in core.REQUIRED:
                    dest = installed / member
                    dest.parent.mkdir(parents=True,exist_ok=True)
                    dest.write_bytes((source/member).read_bytes())
                return subprocess.CompletedProcess(args, 0)
            with patch.object(apply_update.os, 'geteuid', return_value=0), \
                 patch.object(apply_update.subprocess, 'run', side_effect=mock_install):
                backup = apply_update.install(archive, digest, install_root=installed)
            self.assertEqual(core.installed_version(installed),'4.2')
            self.assertEqual((backup/'VERSION').read_text().strip(),'4.0')
            self.assertEqual((backup/'backend/server.py').read_text(),'old')

    def test_privileged_install_rolls_back_on_failure(self):
        with tempfile.TemporaryDirectory() as tmp:
            temp=Path(tmp);installed=temp/'novaos'
            (installed/'backend').mkdir(parents=True)
            (installed/'backend/server.py').write_text('old')
            (installed/'VERSION').write_text('4.0\n')
            archive=make_zip(temp/'new.zip')
            digest=core.sha256_file(archive)
            with patch.object(apply_update.os,'geteuid',return_value=0), \
                 patch.object(apply_update.subprocess,'run',side_effect=subprocess.CalledProcessError(1,'bash')), \
                 self.assertRaises(subprocess.CalledProcessError):
                apply_update.install(archive,digest,install_root=installed)
            self.assertEqual(core.installed_version(installed),'4.0')
            self.assertEqual((installed/'backend/server.py').read_text(),'old')

    def test_debian_trixie_polkit_agent_available(self):
        packages=(ROOT/'builder/novaos.list.chroot').read_text()
        install=(ROOT/'installer/install-on-debian.sh').read_text()
        cfg=(ROOT/'installer/configure-system.sh').read_text()
        self.assertIn('lxpolkit', packages)
        self.assertIn('lxpolkit', install)
        self.assertNotIn('policykit-1-gnome', packages)
        self.assertNotIn('policykit-1-gnome', install)
        self.assertIn('novaos-polkit-agent.desktop', cfg)

    def test_pacakage_contains_both_update_paths_and_no_loss(self):
        builder=(ROOT/'builder/build-iso.sh').read_text()
        config=(ROOT/'installer/configure-system.sh').read_text()
        install=(ROOT/'installer/install-on-debian.sh').read_text()
        js=(ROOT/'web/app.js').read_text()
        self.assertIn('updater,VERSION',builder)
        self.assertIn('updater,VERSION',install)
        self.assertIn('novaos-update-center.desktop',config)
        self.assertIn('novaos-update-check.desktop',config)
        self.assertIn('novaos-update-apply',config)
        self.assertIn("id:'nova_update'",js)
        self.assertIn('touchpad_move',(ROOT/'web/remote.html').read_text())
        self.assertIn('novaos-lg-setup.service',config)
        self.assertIn('power_menu',(ROOT/'backend/server.py').read_text())
        self.assertIn('NovaOS-4.1-amd64.iso',builder)
        self.assertTrue((ROOT/'NOVAOS_4_1_AKTUALISIEREN.sh').exists())


if __name__ == '__main__':
    unittest.main()
