import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class PackagingTests(unittest.TestCase):
    def test_files_for_installation(self):
        files = [
            'NOVAOS_4_0_USB_STARTEN.bat', 'windows/NovaOS-USB-Assistent.ps1',
            'builder/build-iso.sh', 'builder/from-windows.sh', 'builder/novaos.list.chroot',
            'installer/novaos-tv', 'installer/novaos-install',
            'installer/configure-system.sh','installer/novaos-serial-groups.service',
            'installer/novaos-phone-mirror','installer/novaos-diagnose','web/help.html',
            'arduino/NovaOS_IR_2_0/NovaOS_IR_2_0.ino', 'backend/controls.py', 'NOVAOS_4_0_AKTUALISIEREN.sh'
        ]
        for file in files:
            with self.subTest(file=file):self.assertTrue((ROOT/file).is_file())
    def test_installer_packages(self):
        pkg=(ROOT/'builder/novaos.list.chroot').read_text()
        for name in ('calamares','firefox-esr','vlc','kodi','arduino','scrcpy','adb','python3-serial','onboard','playerctl','xvkbd'):
            self.assertIn(name,pkg.splitlines())
    def test_builder_version_matches_outputs(self):
        builder=(ROOT/'builder/build-iso.sh').read_text()
        wsl=(ROOT/'builder/from-windows.sh').read_text()
        ps=(ROOT/'windows/NovaOS-USB-Assistent.ps1').read_text()
        for text in (builder, wsl, ps):
            self.assertIn('NovaOS-4.1-amd64.iso', text)
        self.assertIn('--debian-installer none', builder)

    def test_new_ir_firmware_for_all_commands(self):
        sketch=(ROOT/'arduino/NovaOS_IR_2_0/NovaOS_IR_2_0.ino').read_text()
        self.assertIn('IRremote.hpp', sketch)
        self.assertIn('EXPECTED_ADDRESS = 0x7F00', sketch)
        self.assertIn('IR:NEC:', sketch)
        self.assertNotIn('isKnownCommand', sketch)

    def test_backports_for_scrcpy(self):
        script=(ROOT/'builder/build-iso.sh').read_text()
        self.assertIn('trixie-backports.list.chroot',script)
        self.assertIn('trixie-backports.list.binary',script)
    def test_live_installer_desktop_directory_created_first(self):
        script = (ROOT / 'installer/configure-system.sh').read_text()
        create = script.index('install -d /etc/skel/Desktop')
        copy = script.index('cp /usr/share/applications/novaos-install.desktop /etc/skel/Desktop/')
        self.assertLess(create, copy, 'Live-Build braucht /etc/skel/Desktop vor dem Kopieren')

    def test_key_help_is_accessible_in_ui(self):
        frontend=(ROOT/'web/index.html').read_text()
        js=(ROOT/'web/app.js').read_text()
        self.assertIn('keyHelpOverlay',frontend)
        self.assertIn('keyHelpToggle',frontend)
        self.assertIn('showKeyHint',js)
        self.assertIn("e.key==='F1'",js)

    def test_dedicated_kiosk_profile(self):
        data=(ROOT/'installer/novaos-tv').read_text()
        self.assertIn('--no-remote',data)
        self.assertIn('--profile',data)

if __name__=='__main__':unittest.main()
