"""Additional NovaOS 4.0 tests for touchpad, setup and distribution integrity."""
import os, tempfile, importlib.util, sys, unittest, pathlib
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parents[1]
# Reuse the existing initialized server module to avoid starting a second state directory.
from test_novaos import nova

class Version4Tests(unittest.TestCase):
    def test_version(self):
        self.assertEqual(nova.NovaHandler.server_version,'NovaOS/4.1')
        self.assertIn('setup',nova.APPLICATIONS)

    def test_touchpad_boundaries(self):
        for dx,dy in [(161,0),(-161,0),(0,999),(1.3,2),(True,0),('10',0)]:
            with self.subTest(dx=dx,dy=dy), self.assertRaises(ValueError):
                nova.touchpad_move({'dx':dx,'dy':dy})
        with patch.object(nova,'WINDOWS',True),self.assertRaises(ValueError):
            nova.touchpad_move({'dx':10,'dy':0})

    def test_touchpad_actual_command(self):
        with patch.object(nova,'WINDOWS',False), patch.object(nova.shutil,'which',return_value='/usr/bin/xdotool'), patch.object(nova.subprocess,'run') as runner:
            self.assertEqual(nova.touchpad_move({'dx':5,'dy':-6}),'Mauszeiger bewegt')
            runner.assert_called_once_with(['xdotool','mousemove_relative','--','5','-6'],check=True,timeout=3)

    def test_diagnostics_read_only(self):
        with patch.object(nova,'WINDOWS',False):
            diag=nova.NovaHandler.local_check(None)
        self.assertIn('apps',diag)
        self.assertIn('audio',diag)
        self.assertIn('arduino_devices',diag)
        self.assertIn('ip',diag)
        self.assertEqual(diag['version'],'4.1')

    def test_app_firefox_uses_normal_profile_not_locked_tv_profile(self):
        with patch.object(nova,'WINDOWS',False), patch.object(nova.shutil,'which',return_value='/usr/bin/firefox-esr'), patch.object(nova,'hide_home_window'), patch.object(nova,'run_command') as cmd:
            nova.open_url('https://example.org')
            cmd.assert_called_once_with(['firefox-esr','--new-window','https://example.org'])

    def test_static_assets_and_guide(self):
        remote=(ROOT/'web/remote.html').read_text()
        app=(ROOT/'web/app.js').read_text()
        setup=(ROOT/'web/setup.html').read_text()
        index=(ROOT/'web/index.html').read_text()
        self.assertIn('touchpad_move',remote)
        self.assertIn('pointermove',remote)
        self.assertIn('Einfacher Modus',index)
        self.assertIn("prefs.easyMode",app)
        self.assertIn('/api/check',setup)
        self.assertIn('NOVAOS_4_1_USB_STARTEN.bat',(ROOT/'README.md').read_text())

    def test_install_scripts_consistent(self):
        for f in ['builder/build-iso.sh','builder/from-windows.sh','windows/NovaOS-USB-Assistent.ps1']:
            self.assertIn('NovaOS-4.1-amd64.iso',(ROOT/f).read_text())
        shell=(ROOT/'installer/configure-system.sh').read_text()
        self.assertIn('/usr/share/applications/novaos-setup.desktop',shell)
        self.assertIn('install -d /etc/skel/Desktop',shell)
        self.assertTrue((ROOT/'NOVAOS_4_1_AKTUALISIEREN.sh').exists())

if __name__=='__main__':unittest.main()
