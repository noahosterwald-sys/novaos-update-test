"""Sicherheits- und Regressionstests fuer NovaOS 4.0 ohne echte Hardware."""
from __future__ import annotations
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from urllib.error import HTTPError
from urllib.request import Request, urlopen
from unittest.mock import patch
from test_novaos import nova
from lg_remote import check_key_name, LG_DEFAULT_MAP
ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("nova_calibration", ROOT / "lg-remote/prepare_calibration.py")
cal = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cal)


class Version4FeatureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = nova.ThreadingHTTPServer(("127.0.0.1", 0), nova.NovaHandler)
        cls.port = cls.server.server_port
        cls.thread = __import__('threading').Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown(); cls.server.server_close(); cls.thread.join(3)

    def query(self, path, obj=None, extra_headers=None):
        headers = {"Content-Type":"application/json"}
        headers.update(extra_headers or {})
        payload = json.dumps(obj).encode('utf-8') if obj is not None else None
        req = Request(f"http://127.0.0.1:{self.port}{path}", data=payload,
                      headers=headers, method='POST' if payload is not None else 'GET')
        return urlopen(req, timeout=3)

    def test_version_4_and_48_actions(self):
        self.assertEqual(json.load(self.query('/api/health'))['version'], '4.1')
        data = json.load(self.query('/api/controls'))
        self.assertEqual(data['count'], 48)
        self.assertIn('power_menu', data['groups']['Programme & System'])

    def test_lg_key_identifiers_and_defaults(self):
        self.assertTrue(check_key_name('KEY_VOLUMEUP'))
        self.assertFalse(check_key_name('KEY_VOLUMEUP;rm -rf /'))
        self.assertFalse(check_key_name('not-key'))
        self.assertEqual(LG_DEFAULT_MAP['KEY_POWER'], 'power_menu')
        self.assertNotIn('KEY_UP', LG_DEFAULT_MAP)
        self.assertNotIn('BTN_LEFT', LG_DEFAULT_MAP)

    def test_lg_learning_local_and_persistent(self):
        with patch.object(nova, 'save_state'), patch.object(nova, 'dispatch_control') as run:
            nova.execute_action('lg_learn', {'name':'volup'},local=True)
            nova.lg_event('KEY_F1', 1)
            self.assertEqual(nova.STATE['lg_map']['KEY_F1'],'volup')
            self.assertIsNone(nova.PENDING_LG)
            run.assert_not_called()  # Anlernen darf noch nichts ausfuehren
            nova.lg_event('KEY_F1', 1)
            run.assert_called_once_with('volup')
            nova.STATE['lg_map'].pop('KEY_F1',None)
        with self.assertRaises(ValueError): nova.execute_action('lg_learn',{'name':'shutdown'},local=True)
        with self.assertRaises(ValueError): nova.execute_action('lg_learn',{'name':'volup'},local=False)

    def test_lg_button_release_not_executed(self):
        with patch.object(nova,'dispatch_control') as command:
            nova.lg_event('KEY_VOLUMEUP',0)
            command.assert_not_called()

    def test_software_catalog_no_arbitrary_shell(self):
        self.assertEqual(len(nova.SOFTWARE_CATALOG),8)
        with self.assertRaises(ValueError):nova.software_install('gimp;rm -rf /')
        with self.assertRaises(ValueError):nova.execute_action('install_software', {'package':'gimp'}, local=False)
        with patch.object(nova, 'software_install', return_value='Gestartet') as installer:
            self.assertEqual(nova.execute_action('install_software', {'package':'gimp'},local=True),'Gestartet')
            installer.assert_called_once_with('gimp')
        self.assertEqual(len(json.load(self.query('/api/software'))['apps']),8)

    def test_local_desktop_launcher_rejects_arbitrary_ids(self):
        with patch.object(nova,'desktop_apps',return_value=[{'id':'vlc','name':'VLC'}]), \
             patch.object(nova.shutil,'which',return_value='/usr/bin/gtk-launch'), \
             patch.object(nova,'run_command') as command,patch.object(nova,'hide_home_window'):
            nova.launch_desktop_app('vlc')
            command.assert_called_once_with(['gtk-launch','vlc'])
            with self.assertRaises(ValueError):nova.launch_desktop_app('vlc; touch /tmp/evil')
        with self.assertRaises(ValueError):nova.execute_action('launch_desktop_app',{'id':'vlc'},local=False)

    def test_shutdown_is_always_confirmed_and_uses_no_shell(self):
        with patch.object(nova,'WINDOWS',False), patch.object(nova.shutil,'which',return_value='/usr/bin/zenity'), \
             patch.object(nova.threading,'Thread') as thread, patch.object(nova.subprocess,'run') as proc:
            message = nova.execute_action('power_menu', local=True)
            self.assertIn('bestätigen',message)
            thread.return_value.start.assert_called_once()
            proc.assert_not_called()  # kein direktes Ausschalten
        with patch.object(nova,'WINDOWS',True), self.assertRaises(ValueError):nova.power_menu()

    def test_reject_external_origin_in_post(self):
        with self.assertRaises(HTTPError) as exc:
            self.query('/api/action',{'action':'power_menu'}, {'Origin':'https://fremde-webseite.de'})
        self.assertEqual(exc.exception.code,403)

    def test_reject_wrong_post_content_type(self):
        with self.assertRaises(HTTPError) as exc:
            self.query('/api/action',{'action':'power_menu'}, {'Content-Type':'text/plain'})
        self.assertEqual(exc.exception.code,415)

    def test_no_destructive_installation_on_boot(self):
        config = (ROOT/'installer/configure-system.sh').read_text()
        self.assertIn('novaos-lg-setup.service',config)
        self.assertIn('ATTRS{name}=="LG Magic Remote"',config)
        self.assertIn('TAG-="power-switch"',config)
        self.assertIn('novaos-app-install',config)
        self.assertIn('lg-remote', (ROOT/'builder/from-windows.sh').read_text())
        app_installer=(ROOT/'installer/novaos-app-install').read_text()
        self.assertIn('case "$id"',app_installer)
        self.assertNotIn('eval ', app_installer)
        self.assertIn('pkexec ', app_installer)

    def test_merge_calibration_preserves_measured_values(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)
            (p/'a.json').write_text(json.dumps({'accel':{'bias':[1,2,3], 'matrix':[[1,0,0],[0,1,0],[0,0,1]]},'gyro':{'bias':[0,0,0]}}))
            (p/'g.json').write_text(json.dumps({'gyro':{'bias':[5,6,7], 'scale':[0,0,0]}}))
            result=cal.merge(p/'a.json',p/'g.json')
            self.assertEqual(result['accel']['bias'],[1,2,3])
            self.assertEqual(result['gyro']['bias'],[5,6,7])
            self.assertEqual(result['gyro']['scale'],[0.07]*3)
            (p/'g.json').write_text(json.dumps({'gyro':{'bias':[5,float('nan'),7]}}))
            with self.assertRaises(ValueError): cal.merge(p/'a.json',p/'g.json')

    def test_previous_remote_stays_integrated(self):
        phone=(ROOT/'web/remote.html').read_text()
        self.assertIn('pointermove',phone)
        self.assertIn('touchpad_move',phone)
        self.assertIn('pointercancel',phone)
        self.assertIn('data-control',phone)
        self.assertIn('IR:NEC:7F00:5E', (ROOT/'backend/server.py').read_text())

    def test_ui_has_new_sections(self):
        index=(ROOT/'web/index.html').read_text()
        js=(ROOT/'web/app.js').read_text()
        for id in ['navPrograms','powerToggle','appGrid','settingsToggle']:
            self.assertIn('id="'+id+'"',index)
        for keyword in ['programmeHTML','loadLg','powerFromSettings','data-lg-learn','textSize','cardShape','install_software']:
            self.assertIn(keyword,js)


if __name__=='__main__':unittest.main()
