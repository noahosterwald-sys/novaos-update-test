"""Tests für NovaOS-Backend (ohne Hardwarezugriff)."""
from __future__ import annotations
import importlib.util
import json
import os
import sys
from pathlib import Path
import tempfile
import threading
from urllib.error import HTTPError
from urllib.request import urlopen, Request
import unittest
from unittest.mock import patch

os.environ['NOVAOS_CONFIG_DIR'] = tempfile.mkdtemp(prefix='novaos-test-')
SOURCE = Path(__file__).resolve().parents[1] / 'backend' / 'server.py'
sys.path.insert(0, str(SOURCE.parent))
spec = importlib.util.spec_from_file_location('novaos_server', SOURCE)
nova = importlib.util.module_from_spec(spec)
spec.loader.exec_module(nova)


class BackendTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = nova.ThreadingHTTPServer(('127.0.0.1', 0), nova.NovaHandler)
        cls.port = cls.server.server_port
        nova.PORT = cls.port
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=3)

    def get(self, path):
        return urlopen(f'http://127.0.0.1:{self.port}{path}', timeout=3)

    def post(self, path, data, headers=None):
        payload = json.dumps(data).encode()
        req = Request(f'http://127.0.0.1:{self.port}{path}', data=payload,
                      headers={'Content-Type': 'application/json', **(headers or {})}, method='POST')
        return urlopen(req, timeout=3)

    def test_frontend(self):
        self.assertIn(b'NovaOS', self.get('/').read())
        self.assertIn(b'Fernbedienung', self.get('/remote.html').read())
        self.assertIn(b'Fernbedienung', self.get('/remote').read())

    def test_health_and_local_pair_code(self):
        data = json.load(self.get('/api/health'))
        self.assertEqual(data['version'], '4.1')
        pair = json.load(self.get('/api/local'))
        self.assertEqual(len(pair['pin']), 6)
        self.assertEqual(pair['url'], f'http://{data["ip"]}:{self.port}/remote')

    def test_pairing(self):
        with self.assertRaises(HTTPError) as wrong:
            self.post('/api/pair', {'pin': '000abc'})
        self.assertEqual(wrong.exception.code, 401)
        data = json.load(self.post('/api/pair', {'pin': nova.STATE['pair_pin']}))
        self.assertEqual(data['token'], nova.STATE['remote_token'])

    def test_static_path_escape_blocked(self):
        with self.assertRaises(HTTPError):
            self.get('/%2E%2E/%2E%2E/etc/passwd')

    def test_ir_learning(self):
        result = json.load(self.post('/api/action', {'action': 'ir_learn', 'key': 'up'}))
        self.assertTrue(result['ok'])
        nova.handle_ir_code('IR:4:1A:2B', '/dev/ttyACM0')
        self.assertEqual(nova.STATE['ir_map']['IR:4:1A:2B'], 'up')
        self.assertIsNone(nova.PENDING_IR)

    def test_blaupunkt_preset_maps_all_nine_keys(self):
        expected = {'5E':'up','56':'down','5B':'left','58':'right','5A':'ok',
                    '4E':'back','1E':'volup','5F':'voldown','57':'home'}
        with patch.dict(nova.STATE, {'ir_map': {}}, clear=False), \
             patch.object(nova, 'dispatch_control') as event:
            for command, action in expected.items():
                with self.subTest(command=command):
                    event.reset_mock()
                    nova.handle_ir_code('IR:NEC:7F00:' + command, '/dev/ttyACM0')
                    event.assert_called_once_with(action)

    def test_46_control_options_are_declared(self):
        from controls import CONTROL_LABELS
        self.assertEqual(len(CONTROL_LABELS), 48)
        data = json.load(self.get('/api/controls'))
        self.assertEqual(data['count'], 48)
        self.assertTrue(data['groups']['Maus & Scrollen']['mouse_left'])

    def test_ir_new_button_learning(self):
        from controls import CONTROL_LABELS
        with patch.object(nova, 'save_state'):
            for action in CONTROL_LABELS:
                nova.execute_action('ir_learn', {'key': action})
                nova.handle_ir_code('IR:NEC:7F00:10', '/dev/ttyACM0')
                self.assertEqual(nova.STATE['ir_map']['IR:NEC:7F00:10'], action)

    def test_control_dispatcher_rejects_shell_commands(self):
        with self.assertRaises(ValueError):
            nova.dispatch_control('rm -rf /')
        with self.assertRaises(ValueError):
            nova.execute_action('control', {'name':'Alt+F4; rm -rf'})

    def test_left_right_mouse_browser_only(self):
        from controls import perform_x11
        with patch('controls.browser_is_active', return_value=True), patch('controls._mouse') as m:
            perform_x11('left')
            m.assert_called_once_with('cursor_left')
        with patch('controls.browser_is_active', return_value=False), patch('controls._xkey') as k:
            perform_x11('left')
            k.assert_called_once_with('Left')

    def test_1_and_2_control_buttons(self):
        with patch('controls._mouse') as m:
            from controls import perform_x11
            perform_x11('mouse_left'); perform_x11('mouse_right')
            self.assertEqual(m.call_args_list[0].args, ('mouse_left',))
            self.assertEqual(m.call_args_list[1].args, ('mouse_right',))

    def test_text_input_checks_length_and_control_chars(self):
        from controls import text_input
        for value in ('', 'a'*161, 'abc\n'):
            with self.assertRaises(ValueError): text_input(value)
        with patch('controls.shutil.which',return_value='/usr/bin/xdotool'), patch('controls._run') as run:
            text_input('Hallo NovaOS')
            self.assertIn('Hallo NovaOS', run.call_args.args[0])

    def test_browser_mouse_mode_can_be_disabled(self):
        with patch.object(nova, 'save_state'), patch.object(nova, 'WINDOWS', False), patch.object(nova.shutil, 'which', return_value='/usr/bin/xdotool'), patch.object(nova.subprocess, 'run') as runner:
            nova.execute_action('browser_arrows_mouse', {'enabled':False})
            nova.send_key('left')
            self.assertIn('Left', runner.call_args.args[0])
        nova.STATE['browser_arrows_mouse']=True

    def test_ir_event_shows_current_key_and_action(self):
        with patch.dict(nova.STATE, {'ir_map': {}}, clear=False), \
             patch.object(nova, 'dispatch_control'), \
             patch.object(nova, 'record_key_press', wraps=nova.record_key_press):
            before = json.load(self.get('/api/key-event'))['seq']
            nova.handle_ir_code('IR:NEC:7F00:5E', '/dev/ttyACM0')
            new = json.load(self.get('/api/key-event'))
            self.assertGreater(new['seq'], before)
            self.assertEqual(new['action'], 'up')
            self.assertEqual(new['code'], 'IR:NEC:7F00:5E')

    def test_double_menu_button_opens_help(self):
        nova.LAST_HOME_PRESS = 0.0
        with patch.dict(nova.STATE, {'ir_map': {}}, clear=False), \
             patch.object(nova, 'dispatch_control') as control, \
             patch.object(nova, 'nova_home_is_active', return_value=True):
            nova.handle_ir_code('IR:NEC:7F00:57', '/dev/ttyACM0')
            nova.handle_ir_code('IR:NEC:7F00:57', '/dev/ttyACM0')
            self.assertEqual(control.call_args_list[0].args, ('home',))
            self.assertEqual(control.call_args_list[1].args, ('show_keys',))
            self.assertEqual(json.load(self.get('/api/key-event'))['action'], 'show_keys')
        nova.LAST_HOME_PRESS = 0.0

    def test_help_list_includes_user_assignments(self):
        from controls import CONTROL_LABELS
        self.assertIn('show_keys', CONTROL_LABELS)
        with patch.object(nova, 'WINDOWS', False), \
             patch.object(nova, 'nova_home_is_active', return_value=False), \
             patch.object(nova.shutil, 'which', return_value='/usr/bin/zenity'), \
             patch.object(nova.subprocess, 'Popen') as popen:
            with patch.dict(nova.STATE, {'ir_map': {'IR:NEC:7F00:AA': 'mouse_left'}}, clear=False):
                self.assertIn('Tastenübersicht geöffnet', nova.keymap_window())
                content = (nova.DATA_DIR/'tastenuebersicht.txt').read_text()
                self.assertIn('0xAA', content)
                self.assertIn('Linksklick', content)
                popen.assert_called_once()

    def test_keymap_uses_styled_ui_when_home_focused(self):
        with patch.object(nova, 'WINDOWS', False), \
             patch.object(nova, 'nova_home_is_active', return_value=True), \
             patch.object(nova.shutil, 'which', return_value='/usr/bin/xdotool'), \
             patch.object(nova.subprocess, 'run') as send:
            self.assertIn('Nova Home', nova.keymap_window())
            send.assert_called_once_with(['xdotool', 'key', 'F1'], timeout=3, check=False)

    def test_key_hint_setting_can_be_toggled(self):
        with patch.object(nova, 'save_state'):
            nova.execute_action('key_hints', {'enabled': False})
            self.assertFalse(json.load(self.get('/api/key-event'))['enabled'])
            with self.assertRaises(ValueError): nova.execute_action('key_hints', {'enabled': 'yes'})
            nova.execute_action('key_hints', {'enabled': True})
            self.assertTrue(json.load(self.get('/api/key-event'))['enabled'])

    def test_unknown_nec_address_ignored(self):
        with patch.dict(nova.STATE, {'ir_map': {}}, clear=False), \
             patch.object(nova, 'execute_action') as event:
            nova.handle_ir_code('IR:NEC:7F01:5E', '/dev/ttyACM0')
            event.assert_not_called()

    def test_version_and_extended_apps(self):
        self.assertEqual(json.load(self.get('/api/health'))['version'], '4.1')
        for app in ('arduino', 'ard', 'zdf', 'radio', 'display', 'bluetooth', 'mirror', 'help', 'diagnose'):
            self.assertIn(app, nova.APPLICATIONS)

    def test_app_launch_hides_kiosk_first(self):
        with patch.object(nova, "WINDOWS", False), patch.object(nova, "hide_home_window") as hide, \
             patch.object(nova, "run_command") as launch, patch.object(nova.shutil, "which", return_value="/usr/bin/thunar"):
            self.assertEqual(nova.open_app("files"), "Dateien gestartet")
            hide.assert_called_once()
            launch.assert_called_once_with(["thunar"])

    def test_local_only_installer(self):
        with self.assertRaises(ValueError):
            nova.execute_action("app", {"id": "install"}, local=False)
        with patch.object(nova, "is_live_system", return_value=False):
            with self.assertRaises(ValueError):
                nova.execute_action("app", {"id": "install"}, local=True)
        with patch.object(nova, "is_live_system", return_value=True), patch.object(nova, "open_app", return_value="Installer gestartet"):
            self.assertEqual(nova.execute_action("app", {"id": "install"}, local=True), "Installer gestartet")

    def test_invalid_actions(self):
        with self.assertRaises(HTTPError) as bad:
            self.post('/api/action', {'action': 'app', 'id': '../../etc/passwd'})
        self.assertEqual(bad.exception.code, 400)
        with self.assertRaises(ValueError):
            nova.open_url('javascript:alert(1)')


if __name__ == '__main__':
    unittest.main()
