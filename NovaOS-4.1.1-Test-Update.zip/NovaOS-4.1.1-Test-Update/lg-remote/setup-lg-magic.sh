#!/usr/bin/env bash
# NovaOS 4.1: installiert den quelloffenen lg-magic Kernel-Treiber via DKMS.
# Nutzt zuerst die vorhandene, funktionierende Quelle des Benutzers.
set -Eeuo pipefail
export DEBIAN_FRONTEND=noninteractive
log(){ printf '[NovaOS LG] %s\n' "$*"; }
die(){ log "FEHLER: $*" >&2; exit 1; }
[[ ${EUID} -eq 0 ]] || die 'Dieses Skript benoetigt Administratorrechte (pkexec oder sudo).'
[[ "$(uname -s)" == Linux ]] || die 'Nur Linux unterstuetzt.'
BASE="/opt/novaos"
[[ -f "$BASE/lg-remote/prepare_calibration.py" ]] || die 'NovaOS-4.1-Dateien fehlen.'
MODE="${1:---manual}"
USER_HOME=''
if [[ -n "${SUDO_USER:-}" && "$SUDO_USER" != root ]]; then
    USER_HOME="$(getent passwd "$SUDO_USER" | cut -d: -f6)"
fi
# Falls via pkexec als root gestartet, lokalen Desktop-Nutzer ermitteln.
if [[ -z "$USER_HOME" && -n "${PKEXEC_UID:-}" ]]; then
    USER_HOME="$(getent passwd "$(id -nu "$PKEXEC_UID")" | cut -d: -f6)"
fi
if [[ -z "$USER_HOME" ]]; then
    for dir in /home/*; do
        if [[ -d "$dir/lg-magic/kernel" ]]; then USER_HOME="$dir"; break; fi
    done
fi
if [[ "$MODE" == --auto ]]; then
    # Keine unbekannten Bluetooth-Geraete automatisch koppeln/entkoppeln.
    # Wenn keine MR20 registriert wurde, setup fuer naechsten Start offenhalten.
    if ! timeout 6 bluetoothctl devices 2>/dev/null | grep -qi 'LGE MR20'; then
        log 'Noch keine LGE MR20 gekoppelt; Einrichtung wird nach Kopplung gestartet.'
        exit 0
    fi
fi
KERNEL="$(uname -r)"
log "Kernel: $KERNEL"
# Falls Modul bereits via DKMS installiert wurde, nicht neu installieren.
if ! dkms status -m lg-magic -v 1.0 -k "$KERNEL" 2>/dev/null | grep -q ": installed"; then
    log 'Installiere Build-Abhaengigkeiten und passende Kernel-Header.'
    apt-get update
    apt-get install -y dkms build-essential git ca-certificates python3 python3-evdev "linux-headers-$KERNEL" || \
        die "Kernel-Header fuer $KERNEL fehlen. Ohne exakt passende Header kein sicherer Treiberbau."
    SOURCE=''
    for dir in "${USER_HOME}/lg-magic" /opt/lg-magic /usr/local/src/lg-magic; do
        if [[ -f "$dir/kernel/dkms.conf" ]]; then SOURCE="$dir"; break; fi
    done
    if [[ -z "$SOURCE" ]]; then
        log 'Lade LGPL/GPL-Quellen von https://github.com/brainrom/lg-magic (Internet noetig).'
        mkdir -p /usr/local/src
        git clone --depth 1 https://github.com/brainrom/lg-magic.git /usr/local/src/lg-magic || \
            die 'Download fehlgeschlagen. Alternativ das Projekt nach ~/lg-magic kopieren.'
        SOURCE=/usr/local/src/lg-magic
    fi
    [[ -f "$SOURCE/kernel/lg_magic_main.c" ]] || die 'Unvollstaendige LG-Quellcodes.'
    install -d /usr/src/lg-magic-1.0
    cp -a "$SOURCE/kernel/." /usr/src/lg-magic-1.0/
    dkms add -m lg-magic -v 1.0 2>/dev/null || true
    dkms build -m lg-magic -v 1.0 -k "$KERNEL" || die 'DKMS Kompilierung fehlgeschlagen; Details: dkms status'
    dkms install -m lg-magic -v 1.0 -k "$KERNEL" || die 'DKMS Installation fehlgeschlagen'
fi
# Firmware-Kalibrierung aus vorhandenen Messergebnissen ableiten,
# KEINE neuen oder erfundenen Kalibrierwerte verwenden.
CAL_SOURCE=''
for dir in "${USER_HOME}/lg-magic" /opt/lg-magic /usr/local/src/lg-magic; do
    if [[ -f "$dir/calib.json" ]] && [[ -f "$dir/scripts/convert_calib.py" ]]; then CAL_SOURCE="$dir"; break; fi
    if [[ -f "$dir/calib_accel.json" && -f "$dir/calib_gyro.json" && -f "$dir/scripts/convert_calib.py" ]]; then CAL_SOURCE="$dir"; break; fi
done
if [[ -n "$CAL_SOURCE" ]]; then
    if [[ -f "$CAL_SOURCE/calib.json" ]]; then
        CAL_JSON="$CAL_SOURCE/calib.json"
    else
        CAL_JSON="$(mktemp /tmp/novaos-lg-calib-XXXXXX.json)"
        python3 "$BASE/lg-remote/prepare_calibration.py" "$CAL_SOURCE/calib_accel.json" "$CAL_SOURCE/calib_gyro.json" "$CAL_JSON"
    fi
    CAL_BIN="$(mktemp /tmp/novaos-lg-calib-XXXXXX.bin)"
    if python3 "$CAL_SOURCE/scripts/convert_calib.py" "$CAL_JSON" "$CAL_BIN" --alpha 0.2 --mouse_k 0.5; then
        install -m644 "$CAL_BIN" /lib/firmware/lg_magic_calib.bin
        log 'Vorhandene Kalibrierung uebernommen.'
    else
        log 'WARNUNG: Kalibrierung konnte nicht konvertiert werden. Keine ungueltige Datei installiert.'
    fi
    rm -f "$CAL_BIN"
    [[ "$CAL_JSON" != "$CAL_SOURCE/calib.json" ]] && rm -f "$CAL_JSON"
else
    log 'Keine bestehenden Kalibrierungsdaten gefunden: Luftmaus muss ggf. kalibriert werden.'
fi
printf '%s\n' lg_magic > /etc/modules-load.d/novaos-lg-magic.conf
printf '%s\n' 'options lg_magic airmouse=1 imu_evdev=1' > /etc/modprobe.d/novaos-lg-magic.conf
if ! modprobe lg_magic; then
    die 'Modul nicht geladen. Bitte DKMS-Status pruefen; automatischer Versuch beim naechsten Start.'
fi
install -d /var/lib/novaos
printf 'kernel=%s\n' "$KERNEL" > /var/lib/novaos/lg-ready
log 'Einrichtung fertig. Falls Maus noch nicht reagiert: Rechner neu starten.'
