#!/usr/bin/env python3
"""Vereint die vom LG-Magic-Projekt erzeugten JSON-Werte ohne Shell-Eingaben."""
import argparse
import json
import math
from pathlib import Path


def scalar_list(value, length):
    if not isinstance(value, list) or len(value) != length:
        raise ValueError(f"Erwartete Liste mit {length} Zahlen")
    out = []
    for item in value:
        if type(item) not in (int, float) or not math.isfinite(item):
            raise ValueError("Nur endliche Zahlen erlaubt")
        out.append(float(item))
    return out


def merge(accel_path, gyro_path):
    accel = json.loads(Path(accel_path).read_text(encoding="utf-8"))
    gyro = json.loads(Path(gyro_path).read_text(encoding="utf-8"))
    a = accel["accel"]
    g = gyro["gyro"]
    scalar_list(a["bias"], 3)
    matrix = a["matrix"]
    if isinstance(matrix, list) and len(matrix) == 3 and all(isinstance(row, list) for row in matrix):
        for row in matrix: scalar_list(row, 3)
    else:
        scalar_list(matrix, 9)
    scalar_list(g["bias"], 3)
    accel["gyro"] = {**g, "scale": [0.07, 0.07, 0.07]}
    return accel


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("accel")
    ap.add_argument("gyro")
    ap.add_argument("output")
    args = ap.parse_args()
    result = merge(args.accel, args.gyro)
    Path(args.output).write_text(json.dumps(result, indent=2), encoding="utf-8")
    print("Kalibrierungsdaten verbunden:", args.output)


if __name__ == "__main__":
    main()
