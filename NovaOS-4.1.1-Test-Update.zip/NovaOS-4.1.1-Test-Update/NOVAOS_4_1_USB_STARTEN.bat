
@echo off
setlocal
cd /d "%~dp0"
title NOVAOS 4.1 - USB-ISO erstellen
chcp 65001 >nul
echo.
echo =====================================================
echo    NOVAOS 4.1 - KOMPLETTVERSION / USB-STICK
echo =====================================================
echo.
echo 1. Das Skript erstellt das ISO mit WSL2 und Debian 13.
echo 2. Rufus schreibt das ISO danach auf den USB-Stick.
echo 3. Auf dem Ziel-PC startest du die INSTALLATION.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\NovaOS-USB-Assistent.ps1"
set "code=%ERRORLEVEL%"
if not "%code%"=="0" echo [NovaOS] Vorgang beendet. Fehlernummer: %code%
echo.
pause
exit /b %code%
