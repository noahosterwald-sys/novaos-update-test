# NovaOS 4.0 – Testbericht

Stand: 15. November 2026. Testumgebung: Linux-Entwicklungscontainer, **nicht** der Lenovo G570.

## Erfolgreiche automatische Prüfungen

- **51 Python-Unit- und HTTP-Tests bestanden.** Das sind 38 übernommene und 13 zusätzliche Tests für NovaOS 4.0.
- Enthalten: bisherige 9 Blaupunkt-Tasten, Touchpad, 48 Steueraktionen, LG-Eventzuordnung, Anlernen, Kalibrierungs-Zusammenführung, App-Whitelist, Programmstart, Power-Bestätigung, API-Zugriffsschutz, Desktop-Integration.
- Python-, Shell- und JavaScript-Dateien wurden separat auf Syntax geprüft.
- Die ZIP wird auf enthaltene Dateien und Hash-Konsistenz überprüft.

## Hier nicht vollständig testbar

- Kompletter ISO-Bau auf Debian 13/WSL und bootfähiger USB-Stick.
- Neue Installation mit Calamares, HDMI-Ton, WLAN und Bluetooth am Ziel-PC.
- Echtes Koppeln/Neuverbinden der LG MR20 und zuverlässige Spezialtasten nach Neustart.
- `pkexec`-Rechteabfrage, Ausschalten/Neustart und eventuelle Xfce-Doppelevents.
- Chromium-Visualisierung: Der Browser wurde in diesem Container durch `ERR_BLOCKED_BY_ADMINISTRATOR` für `file://` und `http://127.0.0.1` blockiert. Deshalb keine erfolgreiche interaktive Browservorschau.

**Fazit:** Der Quellcode hat die automatisierten Prüfungen bestanden. Die Systemintegration auf dem Lenovo muss vor einer produktiven Installation geprüft werden; Fehlerfreiheit auf sämtlicher Hardware kann niemand allein aus Unit-Tests ableiten.
