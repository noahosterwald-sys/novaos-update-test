# NovaOS 4.1 installieren und aktualisieren

## Bereits installiertes NovaOS auf 4.1 bringen

1. ZIP entpacken und den kompletten Projektordner auf den Rechner kopieren.
2. Im Projektordner `bash NOVAOS_4_1_AKTUALISIEREN.sh` ausführen.
3. Nachfrage mit **j** und Administrator-Passwort bestätigen.
4. Bei Erfolg abmelden und erneut anmelden, damit die neuen Desktop-Verknüpfungen verfügbar werden.
5. **NovaOS Home → NovaOS Update-Center** oder **Einstellungen → System → NovaOS Update-Center**.

Die bisherige Installation wird von `installer/install-on-debian.sh` vor dem Überschreiben nach `/opt/novaos.backup.DATUM` verschoben. Benutzereinstellungen und Bluetooth-Kopplungen werden nicht absichtlich zurückgesetzt. Der bereits geladene LG-Treiber muss eventuell neu gestartet werden. Keine neue Kalibrierung, sofern bestehende Daten korrekt vorhanden sind.

## Update-Center verwenden

- **Update-ZIP installieren**: Eine neuere vollständige NovaOS-Quell-ZIP auswählen, Änderung bestätigen, Administrator-Passwort eingeben. Wird zur Sicherung eine Kopie der alten `/opt/novaos` erstellt. ZIP darf keine gefährlichen Archiv-Pfade oder Links enthalten.
- **Online suchen**: Einmalig die HTTPS-Adresse eines eigenen, vertrauenswürdigen NovaOS-Update-Manifests (`release.json`) hinterlegen. Das Update-Center kann danach neuere ZIPs herunterladen und deren SHA256 prüfen. Veröffentlichung muss man selbst einrichten; ohne URL kann der Online-Check kein Update finden.
- **Automatische Benachrichtigung**: Bei XFCE-Anmeldung maximal einmal täglich auf neuere Version prüfen, sofern eine Update-URL hinterlegt ist. Nichts wird unbemerkt installiert.
- **Debian-Pakete aktualisieren**: Über die bisherige „Aktualisierungen“-Kachel im App-Center.

Weitere technische Hinweise und Manifestbeispiel in `updater/README.md`. Online-Updates ohne Herausgeber-Signatur nur aus selbst ausgewählten vertrauenswürdigen Quellen verwenden.

## Neue ISO erstellen

1. Windows-PC mit WSL2 Debian 13, ausreichendem freien Speicher und Internet vorbereiten.
2. Die ZIP entpacken, `NOVAOS_4_1_USB_STARTEN.bat` starten.
3. ISO `NovaOS-4.1-amd64.iso` mit Rufus auf einen USB-Stick schreiben.
4. NovaOS vom Stick im Live-Modus testen; erst nach Datensicherung installieren.

**Die ZIP enthält kein vorgefertigtes ISO.** Ein vollständiger WSL-/ISO-Bau wurde hier nicht durchgeführt. `TESTBERICHT_4_1.md` nennt die geprüften Bestandteile und Grenzen.

## Tests ausführen

```bash
python3 -m unittest discover -s tests -v
node --check web/app.js
bash -n installer/install-on-debian.sh builder/build-iso.sh builder/from-windows.sh NOVAOS_4_1_AKTUALISIEREN.sh
```
