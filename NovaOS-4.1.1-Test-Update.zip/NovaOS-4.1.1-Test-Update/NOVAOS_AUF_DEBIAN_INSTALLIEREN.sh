#!/bin/sh
set -eu
exec sudo bash "$(dirname "$0")/installer/install-on-debian.sh"
