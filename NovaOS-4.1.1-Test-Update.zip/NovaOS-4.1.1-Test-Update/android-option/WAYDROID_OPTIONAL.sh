#!/usr/bin/env bash
# Experimentell! Waydroid / Android-Container mit GAPPS (Play Store ggf. unzertifiziert).
# Nicht Teil der NovaOS 1.0 Standardinstallation. Auf Debian 13 mit Internet starten.
set -Eeuo pipefail
if [[ $EUID != 0 ]]; then echo 'Bitte mit sudo starten.'; exit 1; fi
. /etc/os-release
[[ "${VERSION_CODENAME:-}" == trixie ]] || { echo 'Debian 13 erforderlich.'; exit 1; }
cat <<'INFO'
ACHTUNG: Waydroid braucht Wayland (NovaOS verwendet standardmaessig X11),
Kernel-Unterstuetzung (Binder) und ausreichend RAM.
GApps erfordern ggf. eine nachtraegliche Google-Geraete-Zertifizierung.
Der Play Store ist nicht garantiert funktionstuechtig.
INFO
read -r -p 'Waydroid versuchsweise installieren? Tippe JA: ' choice
[[ "$choice" == JA ]] || exit 0
cat > /etc/apt/sources.list.d/novaos-trixie-backports.sources <<'SOURCES'
Types: deb
URIs: http://deb.debian.org/debian
Suites: trixie-backports
Components: main contrib non-free-firmware
Signed-By: /usr/share/keyrings/debian-archive-keyring.gpg
SOURCES
apt-get update
apt-get install -y -t trixie-backports waydroid
apt-get install -y weston
# Dies laedt ein separates Android-Image. Funktion erfordert Kernel und Wayland.
waydroid init -s GAPPS
printf '\nWaydroid Image eingerichtet. Bitte WAYLAND und Kernel pruefen.\n'
echo 'Start: weston (aus dem Desktop) und danach waydroid session start / waydroid show-full-ui'
