#!/usr/bin/env bash
# NovaOS 4.1: update an already installed Lenovo (does not touch partitions).
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
[[ -f "$ROOT/backend/server.py" ]] || { echo '[FEHLER] ZIP nicht vollstaendig entpackt.'; exit 1; }
[[ -f /opt/novaos/backend/server.py ]] || { echo '[FEHLER] Keine bisherige NovaOS-Installation auf Festplatte entdeckt.'; exit 1; }
if grep -q 'boot=live' /proc/cmdline; then echo '[FEHLER] Im Live-Modus bitte die Vollinstallation nutzen.'; exit 1; fi
printf '\nNOVAOS 4.1: INSTALLIERTES SYSTEM AKTUALISIEREN\n'
printf 'Die alte Installation wird gesichert, persoenliche Einstellungen bleiben erhalten.\n'
printf 'Es wird KEINE Festplatte formatiert und kein Bootloader geaendert.\n'
printf 'Internet ist fuer fehlende Debian-Pakete notwendig.\n'
read -rp 'Update jetzt ausfuehren? [j/N] ' answer
[[ "$answer" =~ ^[jJyY]$ ]] || { echo 'Abgebrochen.'; exit 0; }
sudo bash "$ROOT/installer/install-on-debian.sh"
echo 'FERTIG. Bitte vom Desktop abmelden und wieder anmelden (oder neu starten).'
