# NovaOS 4.1 – Windows 10/11 (PowerShell 5+)
# Der Assistent baut das ISO in WSL2 Debian und oeffnet Rufus.
# Er waehlt NIEMALS selbst eine Festplatte/einen USB-Stick zum Loeschen aus.
param()
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Iso = Join-Path $Root 'NovaOS-4.1-amd64.iso'
$Sha = "$Iso.sha256"
function Say([string]$Message) { Write-Host "[NovaOS] $Message" -ForegroundColor Cyan }
function Fail([string]$Message) { Write-Host "[FEHLER] $Message" -ForegroundColor Red; exit 1 }
function ISOValid {
 if (!(Test-Path $Iso) -or !(Test-Path $Sha)) { return $false }
 $expected = ((Get-Content $Sha -TotalCount 1) -split '\s+')[0].ToLowerInvariant()
 $actual = (Get-FileHash $Iso -Algorithm SHA256).Hash.ToLowerInvariant()
 return $expected.Length -eq 64 -and $actual -eq $expected
}
Say 'NovaOS 4.1 - USB-Assistent [KOMPLETTVERSION]'
Say "Quellen: $Root"
Say 'Windows-PC benoetigt Internet, WSL2 und Debian 13.'
if (ISOValid) {
 Say 'Ein ISO mit korrekter SHA256-Pruefsumme liegt schon vor.'
} else {
 if (!(Get-Command wsl.exe -ErrorAction SilentlyContinue)) { Fail 'Windows-Subsystem fuer Linux (WSL) ist nicht vorhanden. Windows 10/11 erforderlich.' }
 Say 'Pruefe Debian in WSL (direkt statt ueber --list --quiet)...'
 # WSL --list --quiet kann in Windows PowerShell 5 UTF-16 mit Nullzeichen liefern.
 # Ein direkter Start und ein Test der Debian-Versionsdatei sind verlaesslicher.
 # Manche WSL-Versionen geben eine harmlose Warnung zur geschachtelten Virtualisierung auf stderr aus.
 $savedPreference = $ErrorActionPreference
 $ErrorActionPreference = 'Continue'
 try {
   $debianProbe = (& wsl.exe -d Debian -u root -- cat /etc/os-release 2>&1 | Out-String)
   $debianExit = $LASTEXITCODE
 } finally { $ErrorActionPreference = $savedPreference }
 if ($debianExit -ne 0) {
   Write-Host ''
   Write-Host 'Debian konnte in WSL nicht gestartet werden.'
   Write-Host 'Pruefe zuerst mit: wsl -l -v und wsl -d Debian'
   $choose = Read-Host 'Soll WSL mit Debian installiert werden? [J/N]'
   if ($choose -notmatch '^[jJyY]') { Fail 'Bitte erst WSL2 mit Debian einrichten.' }
   Say 'Starte die offizielle WSL-Installation mit Administratorrechten.'
   try { Start-Process -FilePath 'wsl.exe' -ArgumentList @('--install', '-d', 'Debian') -Verb RunAs -Wait } catch { Fail "WSL-Installation konnte nicht gestartet werden: $_" }
   Write-Host 'Bei Bedarf Windows neu starten. Dann diese BAT erneut ausfuehren.' -ForegroundColor Yellow
   exit 2
 }
 if ($debianProbe -notmatch '(?m)^ID=debian\s*$' -or $debianProbe -notmatch '(?m)^VERSION_ID="?13"?\s*$') {
   Fail 'Es wird Debian 13 benoetigt. Bitte Ausgabe von: wsl -d Debian -- cat /etc/os-release pruefen.'
 }
 Say 'Debian 13 wurde erfolgreich erkannt.'
 Say 'Windows-Ordner ermitteln (ohne wslpath) und Quellen kopieren.'
 # Statt "wslpath -a <Windows-Pfad>" (das bei manchen WSL/PowerShell-
 # Kombinationen fehlschlaegt), bestimmen wir den Standard-WSL-Pfad
 # aus dem Windows-Laufwerksbuchstaben. Das funktioniert auch bei Leerzeichen,
 # Klammern und Umlauten im entpackten ZIP-Ordner.
 $winRoot = [System.IO.Path]::GetFullPath($Root).TrimEnd('\')
 # REGEX-Objekt statt $Matches: -notmatch befuellt $Matches bei FALSE nicht sicher.
 $driveMatch = [regex]::Match($winRoot, '^([A-Za-z]):\\(.*)$')
 if (-not $driveMatch.Success) {
   Fail "Der Assistent benoetigt einen Ordner auf einem lokalen Laufwerk (z.B. C:). Gefunden: $winRoot"
 }
 $driveLetter = $driveMatch.Groups[1].Value.ToLowerInvariant()
 $pathSuffix = $driveMatch.Groups[2].Value.Replace('\', '/')
 $unixRoot = "/mnt/$driveLetter/$pathSuffix"
 Say "Windows-Ordner: $winRoot"
 Say "WSL-Pfad: $unixRoot"
 # Wichtig: Ohne einen Test wuerden fehlende /mnt/c-Automounts erst beim
 # langen Build auffallen. Der Test ist bewusst schreibgeschuetzt.
 $savedPreference = $ErrorActionPreference
 $ErrorActionPreference = 'Continue'
 try {
   & wsl.exe -d Debian -u root -- test -f "$unixRoot/backend/server.py" 2>&1 | Out-Null
   $pathProbeExit = $LASTEXITCODE
 } finally { $ErrorActionPreference = $savedPreference }
 if ($pathProbeExit -ne 0) {
   Write-Host "Der Projektordner ist in Debian unter $unixRoot nicht erreichbar." -ForegroundColor Yellow
   Write-Host 'Pruefe, ob das Windows-Laufwerk unter /mnt/ eingebunden wurde ...' -ForegroundColor Yellow
   & wsl.exe -d Debian -u root -- ls -ld ("/mnt/$driveLetter") 2>&1 | Out-Host
   Write-Host "Windows-Ordner: $winRoot" -ForegroundColor Yellow
   Write-Host "Linux-Ordner:   $unixRoot" -ForegroundColor Yellow
   Write-Host 'Bitte schicke diese Ausgaben, falls der Test weiterhin scheitert.' -ForegroundColor Yellow
   Fail 'NovaOS-Dateien auf dem Windows-Laufwerk wurden nicht gefunden. Kein ISO-Bau gestartet.'
 }
 Say 'NovaOS-Projektordner in Debian erfolgreich gefunden.'
 Say 'Jetzt werden Linux-Pakete geladen und das ISO gebaut (mehrere GB).'
 Write-Host 'Warte ab, bis [NovaOS] FERTIG erscheint. Das kann laenger dauern.' -ForegroundColor Yellow
 $savedPreference = $ErrorActionPreference
 $ErrorActionPreference = 'Continue'
 try {
   & wsl.exe -d Debian -u root -- bash "$unixRoot/builder/from-windows.sh" "$unixRoot"
   $wslBuildExit = $LASTEXITCODE
 } finally { $ErrorActionPreference = $savedPreference }
 if ($wslBuildExit -ne 0) { Fail 'Der ISO-Bau ist fehlgeschlagen. Die letzte Fehlermeldung steht oben.' }
 if (!(ISOValid)) { Fail 'Das gebaute ISO fehlt oder seine Pruefsumme stimmt nicht.' }
}
Say "ISO ist bereit: $Iso"
Write-Host 'ACHTUNG: Rufus loescht den ausgewaehlten USB-Stick komplett!' -ForegroundColor Yellow
Write-Host 'Stelle in Rufus bitte ein: ISO auswaehlen, Partitionsschema MBR, Zielsystem BIOS (oder BIOS+UEFI).'
Write-Host 'Fuer Lenovo G570: beim Einschalten F12 druecken und USB waehlen.'
$agree = Read-Host 'Soll Rufus jetzt fuer die USB-Erstellung geoeffnet werden? [J/N]'
if ($agree -notmatch '^[jJyY]') { Say 'ISO liegt bereit. USB-Schritt wurde uebersprungen.'; exit 0 }
$rufus = Get-ChildItem -Path $PSScriptRoot -Filter 'rufus*.exe' -File -ErrorAction SilentlyContinue | Select-Object -First 1
try { Set-Clipboard -Value $Iso } catch { }
Say 'ISO-Dateipfad in die Zwischenablage kopiert.'
Start-Process -FilePath 'explorer.exe' -ArgumentList "/select,`"$Iso`""
if ($rufus) {
  $signature = Get-AuthenticodeSignature -FilePath $rufus.FullName
  if ($signature.Status -eq 'Valid' -and $signature.SignerCertificate.Subject -match 'Akeo Consulting|Pete Batard') {
    Say 'Signiertes Rufus im NovaOS-Ordner gefunden. Starte Rufus.'
    Start-Process -FilePath $rufus.FullName
  } else {
    Say 'Rufus-Datei ist nicht vertrauenswuerdig signiert. Oeffne die offizielle Downloadseite.'
    Start-Process 'https://rufus.ie/de/'
  }
} else {
  Say 'Oeffne die offizielle Rufus-Webseite. Rufus dort laden und ausfuehren.'
  Start-Process 'https://rufus.ie/de/'
}
Write-Host '1) In Rufus unter STARTART -> AUSWAHL das NovaOS-4.1-ISO oeffnen.'
Write-Host '2) RICHTIGEN USB-Stick pruefen und MBR / BIOS einstellen.'
Write-Host '3) START klicken und das Loeschen des USB-Sticks selbst bestaetigen.'
Write-Host '4) Auf dem Lenovo im Live-Modus NOVAOS INSTALLIEREN auswaehlen.'
Write-Host '5) Im grafischen Installer die Zielfestplatte bewusst auswaehlen.'
Write-Host 'KEIN USB-Stick wird automatisch geloescht.'
exit 0
