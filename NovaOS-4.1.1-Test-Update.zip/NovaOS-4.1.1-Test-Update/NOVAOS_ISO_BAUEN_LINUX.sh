#!/bin/sh
set -eu
exec sudo bash "$(dirname "$0")/builder/build-iso.sh"
