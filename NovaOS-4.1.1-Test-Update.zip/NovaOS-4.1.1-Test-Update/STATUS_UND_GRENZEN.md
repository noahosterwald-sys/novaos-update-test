# NovaOS 4.1 – Stand und Grenzen (4.0 + Update-Center)

**Implementiert:** Python-Backend, Fernbedienungslogik, Android-/Blaupunkt-Kompatibilität im bisherigen Projektumfang, Handy-Touchpad, NovaOS-Weboberfläche, App-Katalog, Power-Bestätigungsdialog, LG-DKMS-Setup, ISO-Build-Skripte.

**Hier geprüft:** Python-Unit-/Integrationsprüfungen (ohne reale Geräte), JavaScript- und Shell-Syntax, Programmpaket-Struktur. Einzelheiten `TESTBERICHT_4_0.md`.

**Hier nicht geprüft:** das vollständige Debian-13-ISO-Build, Windows-WSL-Ausführung, echte Festplatteninstallation, LG-Bluetooth-Pairing auf dem Lenovo, Langzeitzuverlässigkeit der LG-Tasten/Luftmaus, XFCE-Doppelevents, HDMI-Audio auf Zielhardware, GUI-Rechteabfrage und tatsächliches Poweroff. Browser-Automation war durch eine Laufzeit-Richtlinie blockiert.

LG-Magic-Quellcode wird nicht in der ZIP mitgeliefert; bei fehlender lokaler Quelle ist Internet zum Nachladen nötig. Der externe Treiber ist nicht von LG zertifiziert. Kein direkter Google Play Store. Manche Streamingdienste erfordern DRM oder schnellere Hardware.

**Vor der Festplatteninstallation unbedingt ein Backup anlegen.** Ein neues Live-ISO wird vom Windows-/Debian-Build-Tool erzeugt; die ZIP ist selbst noch kein bootfähiges ISO.

## Ergänzung 4.1

- Das NovaOS Update-Center ist implementiert und lässt sich lokal aus Nova Home starten. Das tägliche Prüfen benötigt eine einmalig konfigurierte HTTPS-Veröffentlichungsadresse, die **noch nicht existiert**.
- Ein Online-Manifest mit SHA256 ist nicht digital signiert; deshalb nur eigene/vertrauenswürdige Quellen verwenden.
- Die vollständige Installation ist hardwareabhängig und wurde nicht auf dem Lenovo getestet. Debian-Paketänderungen können nicht garantiert rückgängig gemacht werden.
- Die ISO enthält die neue Funktion nach dem Build bereits; alte Benutzerprofile einer Neuinstallation werden nicht automatisch übernommen.
