# NovaOS 4.1 – NovaOS 4.0 + Update-Center

**Komplettprojekt für Debian 13 (XFCE).** Es ist kein fertig gebautes ISO und kein Android-TV-System. Es enthält die ISO-Build-Skripte und ein Installations-/Update-Skript.

## Alles aus NovaOS 4.0 bleibt dabei

- Nova Home mit allen App-Kacheln, Streaming-Webseiten, Firefox, Kodi, VLC, einfachen Modus, Ersteinrichtung und Diagnose.
- LG Magic Remote MR20 mit Treibereinrichtung, individuell zuweisbaren Tasten und vorhandener Luftmaus-Kalibrierung; Blaupunkt-Fernbedienung über Arduino Uno R3.
- 48 Steueraktionen, Browsernavigation, LG- und Arduino-Tastenanlernen, F1-Tastenübersicht.
- Handy-Fernbedienung mit präzisem Touchpad aus NovaOS 2.2 und PIN-Kopplung.
- Bestätigungsdialog für Herunterfahren und Neustarten.
- Programme hinzufügen, Designs, Hintergründe, Farben, Kacheln, Schriftgröße und persönliche Startseite.
- Deutsche Debian-XFCE-Oberfläche, Audio- und WLAN-Einstellungen sowie Desktop.

## Neu in NovaOS 4.1: NovaOS Update-Center

- Neue **Kachel „NovaOS Update-Center“** und Knopf unter **Einstellungen → System**.
- Per Knopfdruck nach einer neuen NovaOS-Version suchen, Versionshinweise lesen und ein Update mit Administratorpasswort installieren.
- Einmalig eine HTTPS-Veröffentlichungsadresse festlegen (beispielsweise `release.json` in einem eigenen GitHub-Projekt). **Es gibt noch keine eingerichtete offizielle Update-Adresse.**
- Tägliche Prüfung beim Anmelden meldet neue Versionen per Desktop-Benachrichtigung. **Kein automatisches Installieren im Hintergrund.**
- Vollständige neuere NovaOS-ZIP vom USB-Stick auswählen und direkt über das Update-Center installieren – auch ohne Veröffentlichungs-Server.
- Vor dem Update wird `/opt/novaos` gesichert. Einstellungen im Benutzerprofil bleiben erhalten; bei Fehlern versucht das Programm die bisherigen NovaOS-Projektdateien wiederherzustellen.
- ZIP-Pfade, Versionsnummern und SHA256 werden vor der Installation kontrolliert; Administrator-Bestätigung ist erforderlich.

**Sicherheit:** Die SHA256-Prüfung ersetzt keine digitale Herausgebersignatur. Installiere nur ZIPs und Online-Updates aus vertrauenswürdigen Quellen. Systempakete verwaltest du weiterhin separat über das bisherige „Aktualisierungen“-Programm.

## NovaOS 4.0 auf 4.1 aktualisieren (empfohlen)

1. Diese ZIP entpacken und den **ganzen Ordner** auf den Lenovo kopieren (USB-Stick ist möglich).
2. Ein Terminal im Ordner öffnen und ausführen:

   ```bash
   bash NOVAOS_4_1_AKTUALISIEREN.sh
   ```

3. Bestätigen, Administratorpasswort eingeben, den Abschluss abwarten, abmelden und erneut anmelden.
4. In Nova Home **„NovaOS Update-Center“** öffnen. Das erste 4.1-Update muss noch über dieses Skript installiert werden, weil 4.0 das Update-Center noch nicht besitzt. Danach künftige vollständige ZIPs im Programm verwenden.

## Neuinstallation / ISO bauen

1. ZIP z. B. nach `C:\NovaOS4-1` entpacken (Windows 11, WSL2 + Debian 13 erforderlich).
2. `NOVAOS_4_1_USB_STARTEN.bat` starten.
3. Auf die erstellte Datei `NovaOS-4.1-amd64.iso` warten, danach mit Rufus auf den ausgewählten USB-Stick schreiben.
4. Am Ziel-PC zunächst **Live-Modus** starten und Maus/Luftmaus, Ton, Apps und WLAN prüfen, bevor du die Festplatte installierst.

**Achtung:** Der USB-Stick wird mit Rufus gelöscht; eine Festplatteninstallation kann Daten auf dem ausgewählten Laufwerk löschen. Das Update-Skript formatiert keine Festplatte.

## Tests und Grenzen

Alle mitgelieferten automatisierten Tests, Python-/JS-/Shell-Syntaxprüfungen und ZIP-Prüfungen sind vor der Freigabe vorgesehen, siehe `TESTBERICHT_4_1.md`.
**Nicht live überprüft:** ISO-Bau auf einem echten Windows-/WSL-PC, Kernel-Treiber mit deiner LG Magic Remote, polkit-Dialog und tatsächliche Installation auf deinem Lenovo. Diese Punkte müssen wir vor dem Einsatz auf dem Zielgerät praktisch testen. Eine Garantie für alle Hardwarefunktionen ist nicht möglich.

Weitere Details: `INSTALLATION.md`, `updater/README.md`, `LG_MAGIC_REMOTE_ANLEITUNG.md`.
