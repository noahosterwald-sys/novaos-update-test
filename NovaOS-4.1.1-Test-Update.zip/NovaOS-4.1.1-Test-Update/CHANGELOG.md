# NovaOS 4.0 – Änderungsübersicht

- 4.0: LG MR20 Bluetooth/HID: evdev-Integration, Sondertasten-Belegung, Anlernen, Status.
- 4.0: Systemd-Einrichtungsskript mit DKMS, passenden Headers, Wiederverwendung vorhandener Kalibrierungsdaten.
- 4.0: Ausschaltmenü mit expliziter Bestätigung für Herunterfahren/Neustart.
- 4.0: Programm-Menü für acht offizielle Debian-Pakete, lokale Desktop-Programme und eigene Webseiten-Kacheln.
- 4.0: Zusätzliche Akzentfarben, Hintergründe, Kartenformen, Schriftgröße, Kontrast, Uhranzeige.
- 4.0: 48 statt 46 Fernbedienungsaktionen, alle neun Blaupunkt-Standardcodes weiterhin integriert.
- 4.0: Handy-Touchpad aus 2.2 und vorhandene System-/App-Funktionen übernommen.
- 4.0: Web-Endpunkte gegen fremde Browser-Origins gehärtet; lokale Installation braucht Admin-Bestätigung.
- 4.0: Neue Hardware-/Sicherheitstests und Diagnose-Anleitung.

## 4.1 – NovaOS Update-Center

- Alle 4.0-Funktionen einschließlich LG-Magic-Remote, Blaupunkt, Handy-Touchpad, Personalisierung, App-Katalog und Ausschaltmenü beibehalten.
- Update-Center unter System und als Start-Kachel; vollständige neuere NovaOS-ZIPs installieren, einmalig Online-Quelle festlegen und Release-Notizen ansehen.
- Tägliche Benachrichtigung über verfügbare Versionen bei eingerichteter HTTPS-Quelle. Updates nur nach Bestätigung und Administrator-Passwort.
- Vor Installation NovaOS-Dateisicherung und bei Fehlern Wiederherstellungsversuch; SHA256-, Versions- und ZIP-Pfadprüfungen.
- Installer und ISO-Build-Vorlagen auf 4.1 umgestellt; Linux-/Windows-Aktualisierungswege erhalten.
