"""NovaOS updater: version checks, HTTPS release metadata and safe ZIP inspection.

Only informs/downloads in the unprivileged desktop session. Installation needs
polkit authorization and is handled by the system-owned apply_update.py.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import urllib.parse
import urllib.request
import zipfile

CURRENT_VERSION = '4.1.1'
CONFIG_PATH = Path.home() / '.config' / 'novaos' / 'update-center.json'
MAX_MANIFEST = 65536
MAX_ARCHIVE = 1_500_000_000
MAX_FILES = 5000
MAX_UNCOMPRESSED = 3_000_000_000
REQUIRED = {'backend/server.py', 'installer/configure-system.sh', 'installer/install-on-debian.sh', 'web/index.html', 'VERSION', 'updater/core.py', 'updater/apply_update.py'}
VERSION_PATTERN = re.compile(r'^\d+\.\d+(?:\.\d+)?$')
SHA_PATTERN = re.compile(r'^[0-9a-fA-F]{64}$')


class UpdateError(ValueError):
    pass


def version_tuple(s):
    if not isinstance(s, str) or not VERSION_PATTERN.fullmatch(s):
        raise UpdateError('Ungültige Versionsnummer.')
    return tuple(int(x) for x in s.split('.'))


def is_newer(latest, current):
    return version_tuple(latest) > version_tuple(current)


def installed_version(root=Path('/opt/novaos')):
    path = Path(root) / 'VERSION'
    try:
        version = path.read_text(encoding='utf-8').strip()
    except OSError:
        return '4.0' if (Path(root) / 'backend/server.py').is_file() else CURRENT_VERSION
    return version if VERSION_PATTERN.fullmatch(version) else CURRENT_VERSION


def https_url(url):
    if not isinstance(url, str) or len(url) > 2048:
        raise UpdateError('Ungültige Update-Adresse.')
    p = urllib.parse.urlsplit(url)
    if p.scheme != 'https' or not p.hostname or p.username or p.password or p.fragment:
        raise UpdateError('Für Online-Updates wird eine HTTPS-Adresse benötigt.')
    if p.hostname in ('localhost', '127.0.0.1') or p.hostname.endswith('.local'):
        raise UpdateError('Lokale Netzadressen sind für Online-Updates nicht erlaubt.')
    try:
        _ = p.port
    except ValueError as exc:
        raise UpdateError('Ungültiger Port.') from exc
    return url


def validate_manifest(data):
    if not isinstance(data, dict) or len(data) > 20:
        raise UpdateError('Update-Manifest ist kein gültiges Objekt.')
    version = data.get('version')
    version_tuple(version)
    download = https_url(data.get('zip_url'))
    digest = data.get('sha256')
    if not isinstance(digest, str) or not SHA_PATTERN.fullmatch(digest):
        raise UpdateError('SHA256-Prüfsumme fehlt oder ist ungültig.')
    notes = data.get('notes', '')
    if not isinstance(notes, str) or len(notes) > 3000:
        raise UpdateError('Änderungstext ist ungültig.')
    return {'version': version, 'zip_url': download, 'sha256': digest.lower(), 'notes': notes}


def _open_https(url, timeout):
    request = urllib.request.Request(https_url(url), headers={'User-Agent': 'NovaOS-Update-Center/4.1.1', 'Accept': 'application/json, application/zip'})
    response = urllib.request.urlopen(request, timeout=timeout)
    try:
        https_url(response.geturl())  # Reject redirect to plaintext HTTP.
    except Exception:
        response.close()
        raise
    return response


def fetch_manifest(url, timeout=15):
    try:
        with _open_https(url, timeout) as resp:
            data = resp.read(MAX_MANIFEST + 1)
    except (OSError, TimeoutError) as exc:
        raise UpdateError(f'Update-Server nicht erreichbar: {exc}') from exc
    if len(data) > MAX_MANIFEST:
        raise UpdateError('Update-Manifest ist zu groß.')
    try:
        obj = json.loads(data.decode('utf-8'))
    except (UnicodeError, ValueError) as exc:
        raise UpdateError('Update-Manifest enthält kein gültiges JSON.') from exc
    return validate_manifest(obj)


def sha256_file(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as file:
        for block in iter(lambda: file.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def download_zip(url, dest, expected_sha, timeout=30):
    if not SHA_PATTERN.fullmatch(expected_sha):
        raise UpdateError('Prüfsumme ungültig.')
    dest = Path(dest)
    # The caller must choose a private directory owned by the desktop user.
    partial = dest.with_suffix('.part')
    size = 0
    h = hashlib.sha256()
    try:
        with _open_https(url, timeout) as src, partial.open('wb') as out:
            while True:
                data = src.read(1024 * 1024)
                if not data:
                    break
                size += len(data)
                if size > MAX_ARCHIVE:
                    raise UpdateError('Update-Paket ist zu groß.')
                h.update(data)
                out.write(data)
        if h.hexdigest() != expected_sha.lower():
            raise UpdateError('Prüfsumme stimmt nicht. Update verworfen.')
        partial.replace(dest)
    finally:
        partial.unlink(missing_ok=True)
    return dest


def inspect_zip(path):
    """Validate members and return (release_version, common_root_prefix).

    No extraction is done here; privileged installer will inspect again.
    """
    try:
        with zipfile.ZipFile(path) as zf:
            infos = zf.infolist()
            if len(infos) > MAX_FILES:
                raise UpdateError('Zu viele Dateien im ZIP.')
            total = 0
            files = {}
            for info in infos:
                name = info.filename
                if not name or '\\' in name or '\x00' in name or name.startswith('/') or ':' in name:
                    raise UpdateError('Unsicherer ZIP-Dateipfad.')
                parts = PurePosixPath(name).parts
                if not parts or any(p in ('.', '..', '') for p in name.strip('/').split('/')):
                    raise UpdateError('Unsicherer relativer ZIP-Dateipfad.')
                mode = info.external_attr >> 16
                if stat.S_IFMT(mode) not in (0, stat.S_IFREG, stat.S_IFDIR):
                    raise UpdateError('ZIP enthält unerlaubte Dateitypen oder Links.')
                if info.is_dir():
                    continue
                total += info.file_size
                if total > MAX_UNCOMPRESSED or info.file_size > MAX_ARCHIVE:
                    raise UpdateError('ZIP-Dateien sind zu groß.')
                if name in files:
                    raise UpdateError('Doppelte ZIP-Dateien.')
                files[name] = info
            # Accept common root (NovaOS-4.1.1-Komplett/) or archive root.
            names = set(files)
            if REQUIRED.issubset(names):
                prefix = ''
            else:
                candidates = {name.split('/', 1)[0] for name in names if '/' in name}
                prefixes = [p + '/' for p in candidates if REQUIRED.issubset({n[len(p)+1:] for n in names if n.startswith(p + '/')})]
                if len(prefixes) != 1:
                    raise UpdateError('ZIP ist kein vollständiges NovaOS-Update.')
                prefix = prefixes[0]
                if not all(n.startswith(prefix) for n in names):
                    raise UpdateError('ZIP enthält Dateien außerhalb des Projektordners.')
            raw_version = zf.read(prefix + 'VERSION')
            if len(raw_version) > 32:
                raise UpdateError('Versionsdatei beschädigt.')
            version = raw_version.decode('ascii').strip()
            version_tuple(version)
            return version, prefix
    except (zipfile.BadZipFile, OSError, UnicodeError, KeyError) as exc:
        raise UpdateError(f'Ungültiges ZIP: {exc}') from exc


def load_config(path=CONFIG_PATH):
    try:
        data = json.loads(Path(path).read_text(encoding='utf-8'))
        url = data.get('manifest_url', '')
        return {'manifest_url': https_url(url) if url else ''}
    except (OSError, ValueError, AttributeError, TypeError):
        return {'manifest_url': ''}


def save_config(url, path=CONFIG_PATH):
    url = https_url(url) if url else ''
    file = Path(path)
    file.parent.mkdir(parents=True, exist_ok=True)
    temp = file.with_suffix('.tmp')
    temp.write_text(json.dumps({'manifest_url': url}, indent=2), encoding='utf-8')
    os.chmod(temp, 0o600)
    temp.replace(file)
