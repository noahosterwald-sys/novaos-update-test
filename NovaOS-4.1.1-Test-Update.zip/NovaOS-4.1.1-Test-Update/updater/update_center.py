#!/usr/bin/env python3
"""TV-friendly local update GUI. Never accepts commands from the phone API."""
from __future__ import annotations
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core import (CONFIG_PATH, UpdateError, download_zip, fetch_manifest,
                  inspect_zip, installed_version, is_newer, load_config,
                  save_config, sha256_file)


def dialog(*args):
    p = subprocess.run(['zenity', *args], text=True, capture_output=True)
    return p.stdout.strip() if p.returncode == 0 else None


def info(message):
    dialog('--info', '--title=NovaOS Update-Center', '--width=560', '--text=' + message)


def error(message):
    dialog('--error', '--title=NovaOS Update-Center', '--width=560', '--text=' + message)


def confirm(message):
    return dialog('--question', '--title=NovaOS Update-Center', '--width=620', '--text=' + message) is not None


def apply_archive(path, expected_sha):
    version, _ = inspect_zip(path)
    current = installed_version()
    if not is_newer(version, current):
        info(f'NovaOS {version} ist nicht neuer als die installierte Version {current}.')
        return
    if not confirm(f'NovaOS {current} → {version} installieren?\n\n'
                   'NovaOS wird vorher gesichert. Persönliche Einstellungen bleiben.\n'
                   'Administratorpasswort erforderlich. Die Installation kann einige Minuten dauern.\n\n'
                   'Nur Updates aus Quellen installieren, denen du vertraust!'):
        return
    if shutil.which('pkexec') is None:
        raise UpdateError('pkexec fehlt. Bitte polkit auf Debian installieren.')
    # Polkit presents a local authentication dialog. The checksum is verified
    # again by the installed root-owned program, after privilege escalation.
    cmd = ['pkexec', '/usr/local/sbin/novaos-update-apply', str(path), expected_sha]
    # Use a terminal for detailed progress and errors, so nothing is hidden.
    # Wait here, do not silently report success when pkexec is cancelled.
    result = subprocess.run(cmd, text=True, capture_output=True)
    if result.returncode != 0:
        error('Update fehlgeschlagen oder abgebrochen.\n\n' +
              (result.stderr or result.stdout or f'Fehlercode {result.returncode}')[-1500:])
    else:
        info('NovaOS wurde aktualisiert. Bitte abmelden und wieder anmelden (oder neu starten).\n\n'
             + (result.stdout[-600:] if result.stdout else ''))


def from_online():
    source = load_config()['manifest_url']
    if not source:
        info('Noch keine Update-Quelle festgelegt.\n\n'
             'Wähle im Menü „Update-Quelle festlegen“ und trage später die '
             'HTTPS-Adresse deiner NovaOS-Veröffentlichungen ein.\n\n'
             'Bereits heruntergeladene NovaOS-ZIPs kannst du sofort lokal installieren.')
        return
    release = fetch_manifest(source)
    current = installed_version()
    if not is_newer(release['version'], current):
        info(f'NovaOS {current} ist aktuell.\nVeröffentlichte Version: {release["version"]}')
        return
    if not confirm(f'Neue NovaOS-Version {release["version"]} verfügbar!\n\n'
                   f'{release["notes"][:1600]}\n\nJetzt herunterladen und installieren?\n'
                   'Prüfsumme wird kontrolliert. Der Anbieter muss vertrauenswürdig sein.'):
        return
    # No user-writable shared filename; separate restrictive directory.
    cache_dir = Path.home() / '.cache' / 'novaos' / 'updates'
    cache_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
    file = cache_dir / f'novaos-{release["version"]}.zip'
    download_zip(release['zip_url'], file, release['sha256'])
    version, _ = inspect_zip(file)
    if version != release['version']:
        file.unlink(missing_ok=True)
        raise UpdateError('Version in ZIP stimmt nicht mit Veröffentlichungsinfo überein.')
    apply_archive(file, release['sha256'])


def from_file():
    filename = dialog('--file-selection', '--title=NovaOS Update-ZIP wählen',
                      '--file-filter=ZIP-Pakete | *.zip')
    if not filename:
        return
    file = Path(filename)
    version, _ = inspect_zip(file)
    sha = sha256_file(file)
    if not confirm(f'Ausgewähltes Paket: NovaOS {version}\n\n'
                   f'SHA256: {sha[:20]}…\n\n'
                   'Lokale Update-ZIPs haben keine Herausgeber-Signatur.\n'
                   'Installiere sie nur, wenn du die Herkunft kennst. Fortfahren?'):
        return
    apply_archive(file, sha)


def set_source():
    old = load_config()['manifest_url']
    url = dialog('--entry', '--title=NovaOS Update-Quelle', '--width=700',
                 '--text=HTTPS-Adresse der NovaOS release.json (leer = deaktivieren):',
                 '--entry-text=' + old)
    if url is None:
        return
    save_config(url.strip())
    info('Update-Adresse gespeichert. NovaOS prüft einmal täglich beim Anmelden '
         'und meldet eine neue Version. Installiert wird erst nach deiner Zustimmung.')


def main():
    if shutil.which('zenity') is None:
        print('Zenity ist nicht installiert.', file=sys.stderr)
        return 1
    while True:
        selection = dialog('--list', '--title=NovaOS 4.1.1 – Update-Center',
                           '--width=660', '--height=420',
                           '--text=Version: ' + installed_version() +
                            '\nAktualisierungen erst nach deiner Bestätigung.',
                           '--column=Aktion', '--column=Beschreibung',
                           'Online nach Updates suchen', 'Veröffentlichte NovaOS-Version suchen',
                           'Update-ZIP installieren', 'Update von USB-Stick oder Download',
                           'Update-Quelle festlegen', 'Einmalig HTTPS-Adresse eintragen',
                           'System-Updates öffnen', 'Debian-Programme separat aktualisieren',
                           'Beenden', 'Update-Center schließen')
        if selection is None or selection == 'Beenden':
            return 0
        try:
            if selection == 'Online nach Updates suchen':
                from_online()
            elif selection == 'Update-ZIP installieren':
                from_file()
            elif selection == 'Update-Quelle festlegen':
                set_source()
            elif selection == 'System-Updates öffnen':
                subprocess.Popen(['gnome-software'], start_new_session=True)
        except (UpdateError, OSError, ValueError, subprocess.SubprocessError) as exc:
            error(str(exc))


if __name__ == '__main__':
    sys.exit(main())
