#!/usr/bin/env python3
"""Silent, at-most-daily desktop notification; never performs installation."""
from __future__ import annotations
import sys
import time
from pathlib import Path
import subprocess

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core import fetch_manifest, installed_version, is_newer, load_config

STAMP = Path.home() / '.cache' / 'novaos' / 'last-update-check'


def main():
    source = load_config()['manifest_url']
    if not source:
        return 0
    try:
        if STAMP.is_file() and time.time() - STAMP.stat().st_mtime < 86400:
            return 0
        release = fetch_manifest(source, timeout=10)
        STAMP.parent.mkdir(parents=True, exist_ok=True)
        STAMP.touch()
        if is_newer(release['version'], installed_version()):
            subprocess.run(['notify-send', '-a', 'NovaOS Update-Center',
                            'NovaOS ' + release['version'] + ' ist verfügbar',
                            'Öffne „NovaOS Update-Center“ zum Aktualisieren.'],
                           timeout=5, check=False)
    except Exception as e:
        # Network down? Do not block the desktop or spam popups.
        print('[NovaOS Update-Center]', e, file=sys.stderr)
    return 0


if __name__ == '__main__':
    sys.exit(main())
