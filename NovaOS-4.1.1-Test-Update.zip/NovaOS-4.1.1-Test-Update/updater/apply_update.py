#!/usr/bin/env python3
"""Privileged NovaOS ZIP installer. Must be launched by polkit, not via HTTP."""
from __future__ import annotations
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core import UpdateError, inspect_zip, installed_version, is_newer, sha256_file, SHA_PATTERN

INSTALL_ROOT = Path('/opt/novaos')


def install(archive, expected_sha, install_root=INSTALL_ROOT, *, invoke_installer=True):
    if os.geteuid() != 0:
        raise UpdateError('Installation erfordert Administratorrechte (pkexec).')
    archive = Path(archive).resolve(strict=True)
    install_root = Path(install_root).resolve()
    if not SHA_PATTERN.fullmatch(expected_sha):
        raise UpdateError('Ungültige SHA256-Prüfsumme.')
    if not archive.is_file() or sha256_file(archive) != expected_sha.lower():
        raise UpdateError('Prüfsumme des Update-Pakets stimmt nicht.')
    if not (install_root / 'backend/server.py').is_file():
        raise UpdateError('NovaOS ist auf diesem Rechner nicht installiert.')
    if 'boot=live' in Path('/proc/cmdline').read_text():
        raise UpdateError('Im Live-Modus keine Festplatten-Updates. Stattdessen Vollinstallation wählen.')
    current = installed_version(install_root)
    latest, prefix = inspect_zip(archive)
    if not is_newer(latest, current):
        raise UpdateError(f'Update {latest} ist nicht neuer als installiertes NovaOS {current}.')
    # Keep a persistent rescue copy, including any older NovaOS custom files.
    backup = install_root.parent / f'novaos-vor-update-{time.strftime("%Y%m%d-%H%M%S")}'
    number = 1
    while backup.exists():
        backup = Path(str(backup) + f'-{number}')
        number += 1
    print(f'[NovaOS] Sicherung: {backup}', flush=True)
    shutil.copytree(install_root, backup, symlinks=False)
    try:
        with tempfile.TemporaryDirectory(prefix='novaos-staging-', dir='/var/tmp') as tmp:
            # Safe only because inspect_zip rejects unsafe paths and symlinks.
            with zipfile.ZipFile(archive) as zf:
                zf.extractall(tmp)
            source = Path(tmp) / prefix
            if not (source / 'installer/install-on-debian.sh').is_file():
                raise UpdateError('Installationsskript fehlt.')
            if invoke_installer:
                print(f'[NovaOS] Aktualisiere {current} → {latest} ...', flush=True)
                subprocess.run(['bash', str(source / 'installer/install-on-debian.sh')], check=True)
                if installed_version(install_root) != latest:
                    raise UpdateError('Installer meldete Erfolg, aber die neue Version fehlt!')
            else:
                # Used by isolated tests: do not make any changes to the host.
                print(f'[TEST] Paket {latest} vollständig geprüft.', flush=True)
    except Exception:
        if invoke_installer:
            print('[NovaOS] Fehler: alte NovaOS-Projektdateien wiederherstellen ...', flush=True)
            if install_root.exists():
                shutil.rmtree(install_root)
            shutil.copytree(backup, install_root)
            # Attempt to restore startup files as well; Debian package changes
            # cannot be automatically rolled back.
            old_config = install_root / 'installer/configure-system.sh'
            if old_config.is_file():
                try:
                    subprocess.run(['sh', str(old_config)], check=False)
                except OSError as restore_error:
                    print('[WARNUNG] Systemkonfiguration konnte nicht neu angewendet werden:', restore_error, flush=True)
        raise
    print(f'[NovaOS] Update auf {latest} abgeschlossen. Einstellungen im Home-Verzeichnis bleiben erhalten.', flush=True)
    print('[NovaOS] Bitte abmelden und neu anmelden (oder neu starten).', flush=True)
    return backup


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('zip_path')
    parser.add_argument('sha256')
    args = parser.parse_args()
    try:
        install(args.zip_path, args.sha256)
        return 0
    except (UpdateError, OSError, subprocess.CalledProcessError, zipfile.BadZipFile) as e:
        print('[FEHLER]', e, file=sys.stderr, flush=True)
        return 1


if __name__ == '__main__':
    sys.exit(main())
