# NovaOS 4.1 Update-Center

Neue NovaOS-Versionen werden **nicht ohne Zustimmung installiert**. Das Programm prüft beim Anmelden einmal täglich auf neue Versionen, sobald eine Veröffentlichungs-URL eingerichtet ist. Das gilt nur für NovaOS selbst; Debian-Systemupdates werden weiterhin über GNOME Software verwaltet.

## Updates im Programm

- *Online nach Updates suchen*: Liest eine HTTPS-`release.json`, prüft Version, lädt die ZIP, kontrolliert ihre SHA256-Prüfsumme, zeigt eine Bestätigung und fordert Administratorrechte (`pkexec`) an.
- *Update-ZIP installieren*: Nimmt eine vollständige NovaOS-Projekt-ZIP vom USB-Stick oder aus dem Downloadordner. Die ZIP muss neuer sein als die installierte Version.
- Vor einer Installation wird die bisherige `/opt/novaos`-Installation unter `/opt/novaos-vor-update-*` gesichert. Persönliche Profile unter `~/.config/novaos` und Browser-Einstellungen im Home-Verzeichnis werden nicht gelöscht.
- Bei einem Installationsfehler versucht das Programm, die vorherigen NovaOS-Projektdateien zurückzukopieren. Bereits vorgenommene Debian-Paket-Änderungen lassen sich nicht vollständig automatisch zurückrollen.

## Eigene Veröffentlichungen erstellen

Da noch **kein offizielles NovaOS-Repository veröffentlicht** ist, bleibt die Online-Adresse zunächst leer. In *Update-Center → Update-Quelle festlegen* eine **vertrauenswürdige HTTPS-URL** zu einer Datei `release.json` eintragen, z. B. in einem eigenen GitHub-Repository. Danach kann das Programm online prüfen.

Beispiel für `release.json`:

```json
{
  "version": "4.2",
  "zip_url": "https://github.com/DEIN-NAME/DEIN-REPO/releases/download/v4.2/NovaOS-4.2-Komplett.zip",
  "sha256": "HIER_DEN_64_STELLIGEN_SHA256_HASH_DER_ZIP_EINTRAGEN",
  "notes": "Neue Funktionen und Fehlerbehebungen"
}
```

Hash mit `sha256sum NovaOS-4.2-Komplett.zip` unter Linux oder `Get-FileHash -Algorithm SHA256` in PowerShell erzeugen. Die URL muss per HTTPS erreichbar sein. Das ZIP muss den vollständigen NovaOS-Projektordner inklusive `VERSION`, `installer` und `updater` enthalten.

**Sicherheit:** Eine SHA256-Prüfsumme schützt vor einer unbemerkten Änderung zwischen Manifest und ZIP, sie ist **keine kryptografische Herausgeber-Signatur**. Deshalb die Update-Quelle selbst sorgfältig auswählen. Die App führt keine Updates ohne sichtbare Bestätigung und Administratorpasswort aus. Für Updates aus nicht vertrauenswürdigen Quellen gibt es keine sichere Garantie. Die Funktion ist keine vollautomatische, unbeaufsichtigte Selbstaktualisierung.

## Wiederherstellung

Die Sicherung liegt unter `/opt/novaos-vor-update-DATUM`. Bei Problemen können diese Dateien mit Administratorrechten wiederhergestellt werden. Einstellungen und Treiber aus anderen Systemverzeichnissen müssen ggf. manuell geprüft werden. Vor der ersten Installation auf einem wichtigen PC empfehlen wir einen externen Backup-Datenträger.
