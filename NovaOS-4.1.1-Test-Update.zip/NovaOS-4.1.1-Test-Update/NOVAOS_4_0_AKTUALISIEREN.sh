#!/bin/sh
exec bash "$(dirname "$0")/NOVAOS_4_1_AKTUALISIEREN.sh"
