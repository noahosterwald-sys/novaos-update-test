#!/usr/bin/env bash
# Installation auf DEBIAN 13 mit grafischer Oberfläche.
set -Eeuo pipefail
if [[ $EUID -ne 0 ]]; then echo 'Bitte mit sudo ausführen: sudo bash installer/install-on-debian.sh'; exit 1; fi
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
if [[ ! -f "$ROOT_DIR/backend/server.py" ]]; then echo 'NovaOS-Dateien fehlen.'; exit 1; fi
if [[ ! -f /etc/debian_version ]]; then echo 'Für Debian entwickelt. Installiere bitte zuerst Debian Linux.'; exit 1; fi
export DEBIAN_FRONTEND=noninteractive
printf '\n==> NovaOS 4.1.1 – Test-Update auf Debian\n'
printf '    Apps und benötigte Treiber werden online installiert.\n\n'
# scrcpy is available in Debian 13 backports, not in the regular release.
if ! grep -Rqs '^deb .*trixie-backports' /etc/apt/sources.list /etc/apt/sources.list.d 2>/dev/null; then
  printf '%s\n' 'deb http://deb.debian.org/debian trixie-backports main contrib non-free-firmware' \
    > /etc/apt/sources.list.d/novaos-backports.list
fi
apt-get update
apt-get install -y \
  xorg xfce4 xfce4-terminal lightdm lightdm-gtk-greeter thunar \
  firefox-esr firefox-esr-l10n-de vlc kodi gnome-software \
  network-manager network-manager-gnome \
  pipewire pipewire-audio wireplumber pavucontrol alsa-utils pulseaudio-utils \
  python3 python3-serial xdotool wmctrl curl ca-certificates \
  git avahi-daemon locales fonts-dejavu-core adwaita-icon-theme \
  blueman bluez arandr arduino flatpak gnome-software-plugin-flatpak \
  unattended-upgrades scrcpy adb zenity onboard xvkbd playerctl xfce4-screenshooter \
  python3-evdev dkms build-essential linux-headers-amd64 libgtk-3-bin pkexec lxpolkit libnotify-bin
# Backup bei Upgrade, alten Installationsordner nicht ungefragt entfernen.
if [[ -d /opt/novaos ]]; then
  BACKUP="/opt/novaos.backup.$(date +%Y%m%d-%H%M%S)"
  mv /opt/novaos "$BACKUP"
  echo "Alte Installation gesichert unter $BACKUP"
fi
mkdir -p /opt/novaos
cp -a "$ROOT_DIR"/{backend,web,installer,arduino,assets,diagnose,android-option,lg-remote,updater,VERSION,README.md,INSTALLATION.md,STATUS_UND_GRENZEN.md} /opt/novaos/
sh /opt/novaos/installer/configure-system.sh
# Bei bereits gekoppelter LG MR20: Einrichtung versuchen, andere Updates nicht blockieren.
if command -v bluetoothctl >/dev/null && bluetoothctl devices 2>/dev/null | grep -qi "LGE MR20"; then
  /usr/local/sbin/novaos-lg-setup --auto || echo "LG-Treiber noch nicht fertig: Einstellungen > LG Magic Remote > Einrichten"
fi
if [[ -n "${SUDO_USER:-}" && "${SUDO_USER}" != root ]]; then
  usermod -aG dialout "$SUDO_USER" || true
fi
printf '\n==> Fertig! Bitte abmelden und wieder anmelden.\n'
printf '    NovaOS startet automatisch.\n'
printf '    Alternativ: Anwendungen -> NovaOS Startbildschirm\n\n'
