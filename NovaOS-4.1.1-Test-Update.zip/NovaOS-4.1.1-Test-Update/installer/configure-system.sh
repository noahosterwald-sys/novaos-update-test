#!/bin/sh
# NovaOS-Systemkonfiguration für live-build-Chroot ODER vorhandenes Debian.
set -eu
BASE=/opt/novaos
[ -f "$BASE/backend/server.py" ] || { echo 'FEHLER: /opt/novaos fehlt.' >&2; exit 1; }
install -Dm755 "$BASE/installer/novaos-session" /usr/local/bin/novaos-session
# NovaOS 4.1: App-Installer und automatische LG-Magic-Remote-Einrichtung.
install -Dm755 "$BASE/installer/novaos-app-install" /usr/local/bin/novaos-app-install
# Update-Center: no updater endpoints are exposed via the LAN remote.
install -d /usr/local/bin /usr/local/sbin
cat > /usr/local/bin/novaos-update-center <<'UPDATE'
#!/bin/sh
exec /usr/bin/python3 /opt/novaos/updater/update_center.py "$@"
UPDATE
cat > /usr/local/bin/novaos-update-check <<'CHECK'
#!/bin/sh
exec /usr/bin/python3 /opt/novaos/updater/check_updates.py "$@"
CHECK
cat > /usr/local/sbin/novaos-update-apply <<'APPLY'
#!/bin/sh
exec /usr/bin/python3 /opt/novaos/updater/apply_update.py "$@"
APPLY
chmod 755 /usr/local/bin/novaos-update-center /usr/local/bin/novaos-update-check /usr/local/sbin/novaos-update-apply

install -Dm755 "$BASE/lg-remote/setup-lg-magic.sh" /usr/local/sbin/novaos-lg-setup
install -Dm755 "$BASE/lg-remote/novaos-lg-gui-setup" /usr/local/bin/novaos-lg-gui-setup
install -Dm755 "$BASE/lg-remote/novaos-lg-terminal-setup" /usr/local/bin/novaos-lg-terminal-setup
install -Dm644 "$BASE/lg-remote/novaos-lg-setup.service" /etc/systemd/system/novaos-lg-setup.service
install -d /etc/udev/rules.d /etc/modules-load.d /etc/modprobe.d
cat > /etc/udev/rules.d/90-novaos-lg-remote.rules <<'RULE'
SUBSYSTEM=="input", KERNEL=="event*", ATTRS{name}=="LG Magic Remote", TAG+="uaccess", TAG-="power-switch"
SUBSYSTEM=="input", KERNEL=="event*", ATTRS{name}=="LG Magic Remote IMU", TAG+="uaccess"
RULE
# Im Live-Build per Symlink aktivieren; keine systemctl-Aufrufe in chroot noetig.
install -d /etc/systemd/system/multi-user.target.wants
ln -sf /etc/systemd/system/novaos-lg-setup.service /etc/systemd/system/multi-user.target.wants/novaos-lg-setup.service

install -Dm755 "$BASE/installer/novaos-tv" /usr/local/bin/novaos-tv
install -Dm755 "$BASE/installer/novaos-install" /usr/local/bin/novaos-install
install -Dm755 "$BASE/installer/novaos-phone-mirror" /usr/local/bin/novaos-phone-mirror
install -Dm755 "$BASE/installer/novaos-diagnose" /usr/local/bin/novaos-diagnose
install -Dm755 "$BASE/installer/novaos-serial-groups" /usr/local/sbin/novaos-serial-groups
install -Dm644 "$BASE/installer/novaos-serial-groups.service" /etc/systemd/system/novaos-serial-groups.service
mkdir -p /etc/systemd/system/multi-user.target.wants
ln -sf /etc/systemd/system/novaos-serial-groups.service /etc/systemd/system/multi-user.target.wants/novaos-serial-groups.service
install -Dm755 "$BASE/installer/novaos-android-test" /usr/local/bin/novaos-android-test
install -Dm644 "$BASE/assets/novaos-wallpaper.svg" /usr/share/backgrounds/novaos/wallpaper.svg
install -d /etc/xdg/autostart /usr/share/applications
cat > /etc/xdg/autostart/novaos.desktop <<'EOF'
[Desktop Entry]
Type=Application
Name=NovaOS Autostart
Comment=Startet die NovaOS-TV-Oberfläche beim Anmelden
Exec=/usr/local/bin/novaos-session
Terminal=false
OnlyShowIn=XFCE;
X-GNOME-Autostart-enabled=true
EOF
cat > /usr/share/applications/novaos-tv.desktop <<'EOF'
[Desktop Entry]
Version=1.0
Type=Application
Name=NovaOS TV
Name[de]=NovaOS Startbildschirm
Comment=Zurück zur NovaOS-TV-Oberfläche
Exec=/usr/local/bin/novaos-session
Icon=video-display
Terminal=false
Categories=AudioVideo;Video;
StartupNotify=true
EOF
cat > /usr/share/applications/novaos-remote.desktop <<'EOF'
[Desktop Entry]
Type=Application
Name=NovaOS Fernbedienung
Exec=firefox-esr --new-window http://127.0.0.1:8765/remote
Icon=input-keyboard
Terminal=false
Categories=Settings;Utility;
EOF
cat > /usr/share/applications/novaos-control.desktop <<'EOF'
[Desktop Entry]
Type=Application
Name=NovaOS Einstellungen
Exec=firefox-esr --new-window http://127.0.0.1:8765/
Icon=preferences-system
Terminal=false
Categories=Settings;
EOF

# Debian 13 no longer ships policykit-1-gnome; use the lightweight LXPolkit
# GUI authentication agent in XFCE for pkexec authorization dialogs.
cat > /etc/xdg/autostart/novaos-polkit-agent.desktop <<'POLKIT'
[Desktop Entry]
Type=Application
Name=NovaOS Administrator-Bestätigung
Exec=/usr/bin/lxpolkit
Terminal=false
OnlyShowIn=XFCE;
X-GNOME-Autostart-enabled=true
POLKIT

# Automatic update availability check (notification only, NO automatic installation).
cat > /etc/xdg/autostart/novaos-update-check.desktop <<'DESKTOP'
[Desktop Entry]
Type=Application
Name=NovaOS Update-Prüfung
Comment=Informiert hoechstens einmal am Tag ueber neue NovaOS-Versionen
Exec=/usr/local/bin/novaos-update-check
Terminal=false
OnlyShowIn=XFCE;
X-GNOME-Autostart-enabled=true
DESKTOP
cat > /usr/share/applications/novaos-update-center.desktop <<'DESKTOP'
[Desktop Entry]
Type=Application
Name=NovaOS Update-Center
Comment=NovaOS aktualisieren und Sicherung vor dem Update erstellen
Exec=/usr/local/bin/novaos-update-center
Icon=system-software-update
Terminal=false
Categories=System;Settings;
DESKTOP

# Einfacher Einstieg in die Ersteinrichtung – auch nach Festplatteninstallation.
cat > /usr/share/applications/novaos-setup.desktop <<'DESKTOP'
[Desktop Entry]
Type=Application
Name=NovaOS 4.1 Ersteinrichtung
Exec=firefox-esr --new-window http://127.0.0.1:8765/setup
Icon=preferences-system
Terminal=false
Categories=System;Settings;
DESKTOP
# Direkte Verknuepfung zur Arduino-IDE und zum grafischen Installer im Live-System.
cat > /usr/share/applications/novaos-arduino.desktop <<'DESKTOP'
[Desktop Entry]
Type=Application
Name=NovaOS Arduino Uno R3
Exec=arduino
Icon=arduino
Terminal=false
Categories=Development;Education;
DESKTOP
cat > /usr/share/applications/novaos-install.desktop <<'DESKTOP'
[Desktop Entry]
Type=Application
Name=NovaOS auf Festplatte installieren
Comment=Grafischen Debian-Live-Installer starten (Achtung: Datensicherung!)
Exec=/usr/local/bin/novaos-install
Icon=system-software-install
Terminal=false
Categories=System;
DESKTOP
# Desktop-Ziel zuerst erzeugen: im Live-Build gibt es /etc/skel/Desktop noch nicht.
install -d /etc/skel/Desktop
# Auch im Live-Modus erscheint der Installer als Desktop-Icon.
cp /usr/share/applications/novaos-install.desktop /etc/skel/Desktop/NovaOS-Installieren.desktop
chmod +x /etc/skel/Desktop/NovaOS-Installieren.desktop
# Calamares wird nur auf Live-Medien benoetigt. Auf installiertem Debian
# bleibt die Verknuepfung sichtbar, hat aber keine Wirkung, falls Calamares fehlt.

# Optionaler Android-Handybildschirm über USB auf dem Desktop.
cat > /usr/share/applications/novaos-phone-mirror.desktop <<'DESKTOP'
[Desktop Entry]
Type=Application
Name=NovaOS Handybildschirm (USB)
Exec=/usr/local/bin/novaos-phone-mirror
Icon=video-display
Terminal=false
Categories=Utility;Video;
DESKTOP

cat > /usr/share/applications/novaos-diagnose.desktop <<'DESKTOP'
[Desktop Entry]
Type=Application
Name=NovaOS Diagnose
Exec=xfce4-terminal --hold --command=/usr/local/bin/novaos-diagnose
Icon=utilities-terminal
Terminal=false
Categories=System;Utility;
DESKTOP

# uBlock Origin per Firefox-Unternehmensrichtlinie beim nächsten Online-Start laden.
# Existierende Policies werden nicht überschrieben.
POLICY_DIR=/usr/lib/firefox-esr/distribution
if [ ! -e "$POLICY_DIR/policies.json" ]; then
  mkdir -p "$POLICY_DIR"
  cat > "$POLICY_DIR/policies.json" <<'EOF'
{
  "policies": {
    "ExtensionSettings": {
      "uBlock0@raymondhill.net": {
        "installation_mode": "force_installed",
        "install_url": "https://addons.mozilla.org/firefox/downloads/latest/ublock-origin/latest.xpi"
      }
    }
  }
}
EOF
fi
# Vorlagen für neue XFCE-Benutzer: dunkles Desktop-Thema, Icon für NovaOS.
install -d /etc/skel/Desktop /etc/skel/.config/xfce4/xfconf/xfce-perchannel-xml
cp /usr/share/applications/novaos-tv.desktop /etc/skel/Desktop/NovaOS.desktop
chmod +x /etc/skel/Desktop/NovaOS.desktop
cat > /etc/skel/.config/xfce4/xfconf/xfce-perchannel-xml/xsettings.xml <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xsettings" version="1.0">
  <property name="Net" type="empty">
    <property name="ThemeName" type="string" value="Adwaita-dark"/>
    <property name="IconThemeName" type="string" value="Adwaita"/>
  </property>
</channel>
EOF
# Desktop-Hintergrund wird über xfconf gesetzt, falls X läuft. In der ISO sind
# seine Dateien bereits verfügbar; bei Handinstallation kann ihn der Nutzer wählen.
cat > /usr/share/applications/novaos-lg-remote.desktop <<'DESKTOP'
[Desktop Entry]
Type=Application
Name=NovaOS LG Magic Remote einrichten
Exec=/usr/local/bin/novaos-lg-gui-setup
Icon=input-mouse
Terminal=false
Categories=Settings;Utility;
DESKTOP
echo 'NovaOS 4.1 Systemkonfiguration abgeschlossen.' 
