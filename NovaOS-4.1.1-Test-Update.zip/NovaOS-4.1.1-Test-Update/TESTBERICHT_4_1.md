# Testbericht NovaOS 4.1 (15. November 2026)

## Automatisierte Tests: bestanden

- **63 Python-Unit- und HTTP-Tests** bestanden, darunter 51 übernommene Tests für die bisherigen NovaOS-Funktionen und 12 zusätzliche Tests für den Update-Prozess.
- Funktionale Regressionen: Blaupunkt NEC, LG-Magic-Tasten und IMU-Anbindung, Bluetooth-Anlernlogik, 48 Steueraktionen, bestätigtes Ausschaltmenü, Handy-Touchpad, Audio, Apps, Designs, sichere LAN-API.
- Neue Update-Tests: Versionsvergleich; Erkennen alter 4.0-Installationen; HTTPS-/Manifest-Validierung; ZIP-Projekterkennung mit und ohne Stammordner; Schutz gegen ZIP-Traversal, Links und doppelte Dateinamen; Prüfsumme; gespeicherte Einstellungen; ausschließlich lokaler Start des Update-Centers; simulierte Update-Installation mit Sicherung; simulierte Fehlerbehandlung mit Rücksicherung.
- Debian-13-Kompatibilität: Das aus Trixie entfernte `policykit-1-gnome` wurde vor der Freigabe durch `lxpolkit` ersetzt; Autostart im XFCE-Desktop vorbereitet.
- Statische Prüfungen: `python3 -m compileall`, `node --check web/app.js`, `bash -n` für Shell-Skripte.
- Paketprüfung: ZIP-Datei nach Erstellung erneut entpackt/validiert, SHA256-Dateiliste geprüft (siehe `MANIFEST_SHA256.txt`).

## Nicht auf echter Hardware ausführbar

- End-to-End-ISO-Bau in WSL2/Debian 13 und Boot vom USB-Stick.
- Tatsächlicher Installationslauf mit `apt`, Calamares, `pkexec` und systemd auf dem Lenovo G570.
- Echtes Bluetooth-/LG-Magic-Remote-Verhalten, HDMI-Ton und die Fernbedienungstasten am Fernseher.
- Veröffentlichung einer neuen Release-Datei auf GitHub und echter Online-Download vom Endgerät. **Eine veröffentlichte Update-Quelle existiert noch nicht.**
- Interaktive grafische Prüfung von Zenity auf dem Ziel-PC.

**Status:** Ein in sich stimmiges, statisch und automatisiert geprüftes 4.1-Projekt. Keine Garantie für fehlerfreies Live-Booten oder Hardwareeinrichtung ohne Tests auf dem konkreten Lenovo.
