NovaOS 4.1 - Arduino Uno R3 / Blaupunkt
======================================
Verkabelung: IR-Sensor G -> GND; R -> 5V; Y -> D2.
USB: Arduino direkt an Lenovo; Port muss normalerweise nicht eingegeben werden.

Die neun bisher gemessenen Tasten sind in NovaOS 4.1 bereits hinterlegt.
Wenn du zusaetzliche Tasten (1 und 2 und weitere) verwenden moechtest,
musst du den beiliegenden neuen Sketch EINMAL auf den Uno hochladen.
Das ist KEINE Neuinstallation von NovaOS, sondern ein Arduino-Update.

Hochladen (auf Windows oder im NovaOS-Desktop):
1) Arduino IDE oeffnen und IRremote 4.x (Armin Joachimsmeyer) installieren.
2) NovaOS_IR_2_0/NovaOS_IR_2_0.ino oeffnen.
3) Board = Arduino Uno, Port = USB-Anschluss des Arduino.
4) Hochladen; bei 115200 Baud die seriellen Zeilen pruefen.
5) Seriellen Monitor SCHLIESSEN, dann Arduino am Lenovo anschliessen.

Tasten 1/2 anlernen:
NovaOS -> Einstellungen -> Fernbedienung -> 'Linksklick (Taste 1)'
-> Anlernen -> Taste 1 auf Blaupunkt druecken.
Dasselbe mit 'Rechtsklick (Taste 2)' -> Taste 2 druecken.
Die IR-Codes werden dauerhaft im jeweiligen NovaOS-Benutzerprofil gespeichert.

Die IRremote-Bibliothek fuer den Sketch ist freie Software und wird nicht in
dieser ZIP mitgeliefert. Sie ist ueber die Arduino-IDE installierbar.

Serieller Geraetepfad unter Linux kontrollieren:
readlink -f /dev/serial/by-id/*
Wenn kein Geraet gefunden wird: ls /dev/ttyACM* /dev/ttyUSB* 2>/dev/null
