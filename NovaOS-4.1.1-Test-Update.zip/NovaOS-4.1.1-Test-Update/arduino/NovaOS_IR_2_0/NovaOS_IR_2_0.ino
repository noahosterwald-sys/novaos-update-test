/* NovaOS 4.1 - Blaupunkt Infrarot mit Arduino Uno R3
 * Benoetigt: IRremote >=4 von Armin Joachimsmeyer
 * IR Empfaenger: G -> GND, R -> 5V, Y -> Arduino D2
 * Erkennt ALLE normalen NEC-Tastencodes (auch 1/2 zum Anlernen).
 * Ausgabe: IR:NEC:7F00:5E bei HOCH usw.
 */
#include <IRremote.hpp>
#define IR_INPUT_PIN 2
const uint16_t EXPECTED_ADDRESS = 0x7F00;
unsigned long lastRepeatAt = 0;
void setup() {
  Serial.begin(115200);
  IrReceiver.begin(IR_INPUT_PIN, ENABLE_LED_FEEDBACK);
  Serial.println(F("NOVAOS:IR:2.0:READY"));
}
void loop() {
  if (!IrReceiver.decode()) return;
  IRData &sig = IrReceiver.decodedIRData;
  // Nur Fernbedienungen mit deiner bereits gemessenen NEC-Adresse.
  if (sig.protocol == NEC && sig.address == EXPECTED_ADDRESS) {
    const bool repeat = (sig.flags & IRDATA_FLAGS_IS_REPEAT);
    // Nur beim Gedrueckthalten der Pfeiltasten wiederholen; verhindert
    // doppelte Klicks und 100-prozentige Lautstaerke durch einen Tastendruck.
    bool arrow = sig.command == 0x5E || sig.command == 0x56 ||
                 sig.command == 0x5B || sig.command == 0x58;
    if (!repeat || (arrow && millis() - lastRepeatAt >= 110)) {
      Serial.print(F("IR:NEC:"));
      Serial.print(sig.address, HEX);
      Serial.print(':');
      Serial.println(sig.command, HEX);
      lastRepeatAt = millis();
    }
  }
  IrReceiver.resume();
}
