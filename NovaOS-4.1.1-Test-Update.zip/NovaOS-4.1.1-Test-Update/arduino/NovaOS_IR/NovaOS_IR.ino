/*
 * NovaOS 1.0.1 – Blaupunkt Originalfernbedienung, fest voreingestellt
 * Arduino Uno R3, IR-Sensor: G -> GND, R -> 5V, Y -> D2
 * Bibliothek: IRremote von Armin Joachimsmeyer (4.x)
 *
 * Diese Version sendet genau das vom NovaOS-Backend verstandene Format:
 * IR:NEC:7F00:5E
 * Das Arduino-IDE-Fenster "Serieller Monitor" vor der Nutzung am Lenovo schliessen.
 */
#include <IRremote.hpp>

constexpr uint8_t IR_PIN = 2;
constexpr uint16_t TV_ADDRESS = 0x7F00;

bool isKnownCommand(uint16_t command) {
  switch (command) {
    case 0x5E:  // Hoch
    case 0x56:  // Runter
    case 0x5B:  // Links
    case 0x58:  // Rechts
    case 0x5A:  // OK
    case 0x4E:  // Zurueck
    case 0x1E:  // Lauter
    case 0x5F:  // Leiser
    case 0x57:  // Home/Menue
      return true;
    default:
      return false;
  }
}

void setup() {
  Serial.begin(115200);
  IrReceiver.begin(IR_PIN, ENABLE_LED_FEEDBACK);
  Serial.println("NOVAOS:IR:BLAUPUNKT:READY");
}

void loop() {
  if (!IrReceiver.decode()) return;
  const auto &signal = IrReceiver.decodedIRData;
  // Beim Gedrueckthalten keine unkontrollierten Mehrfachaktionen senden.
  if (signal.protocol == NEC && signal.address == TV_ADDRESS &&
      !(signal.flags & IRDATA_FLAGS_IS_REPEAT) &&
      isKnownCommand(signal.command)) {
    Serial.print("IR:NEC:");
    Serial.print(signal.address, HEX);
    Serial.print(':');
    Serial.println(signal.command, HEX);
  }
  IrReceiver.resume();
}
