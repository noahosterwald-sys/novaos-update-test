"""NovaOS 4.1.1 remote action definitions and X11-specific execution.

Arduino emits NEC button IDs; all additional buttons can be mapped on the TV UI.
Keep actions explicit; never accept arbitrary shell commands or key sequences from LAN.
"""
from __future__ import annotations
from collections import OrderedDict
from pathlib import Path
import os
import re
import shutil
import subprocess
import time

# Categories are shown in Settings > Remote. Each identifier is stable for saved bindings.
CONTROL_GROUPS = OrderedDict([
    ("Navigation", OrderedDict([
        ("up", "Hoch"), ("down", "Runter"), ("left", "Links"),
        ("right", "Rechts"), ("ok", "OK / Bestätigen"), ("back", "Zurück"),
        ("home", "NovaOS-Startseite"), ("desktop", "Desktop anzeigen"),
        ("search", "NovaOS-Suche"), ("show_keys", "Tastenübersicht anzeigen"),
    ])),
    ("Audio & Medien", OrderedDict([
        ("volup", "Lautstärke +"), ("voldown", "Lautstärke −"),
        ("mute", "Stummschalten"), ("play_pause", "Wiedergabe / Pause"),
        ("next_track", "Nächster Titel"), ("prev_track", "Vorheriger Titel"),
    ])),
    ("Maus & Scrollen", OrderedDict([
        ("mouse_left", "Linksklick (Taste 1)"), ("mouse_right", "Rechtsklick (Taste 2)"),
        ("cursor_left", "Mauszeiger links"), ("cursor_right", "Mauszeiger rechts"),
        ("cursor_up", "Mauszeiger hoch"), ("cursor_down", "Mauszeiger runter"),
        ("scroll_up", "Nach oben scrollen"), ("scroll_down", "Nach unten scrollen"),
    ])),
    ("Browser", OrderedDict([
        ("browser_back", "Browser zurück"), ("browser_forward", "Browser vorwärts"),
        ("reload", "Seite neu laden"), ("new_tab", "Neuer Tab"),
        ("close_tab", "Tab schließen"), ("tab_next", "Nächster Tab"),
        ("tab_prev", "Vorheriger Tab"), ("zoom_in", "Vergrößern"),
        ("zoom_out", "Verkleinern"), ("zoom_reset", "Zoom zurücksetzen"),
        ("fullscreen", "Vollbild umschalten"), ("keyboard", "Bildschirmtastatur"),
    ])),
    ("Programme & System", OrderedDict([
        ("launch_youtube", "YouTube öffnen"), ("launch_twitch", "Twitch öffnen"),
        ("launch_spotify", "Spotify öffnen"), ("launch_firefox", "Firefox öffnen"),
        ("launch_kodi", "Kodi öffnen"), ("launch_vlc", "VLC öffnen"),
        ("launch_files", "Dateimanager öffnen"),
        ("launch_arduino", "Arduino IDE öffnen"),
        ("launch_settings", "NovaOS Einstellungen"),
        ("screenshot", "Bildschirmfoto speichern"),
        ("power_menu", "Ausschalten / Neustarten-Menü"),
        ("launch_appstore", "Programme installieren"),
    ])),
])
CONTROL_LABELS = {action: label for group in CONTROL_GROUPS.values() for action, label in group.items()}
KEYS = {
    "up": "Up", "down": "Down", "left": "Left", "right": "Right", "ok": "Return",
    "back": "Alt+Left", "browser_back": "Alt+Left", "browser_forward": "Alt+Right",
    "reload": "ctrl+r", "new_tab": "ctrl+t", "close_tab": "ctrl+w",
    "tab_next": "ctrl+Tab", "tab_prev": "ctrl+shift+Tab", "zoom_in": "ctrl+plus",
    "zoom_out": "ctrl+minus", "zoom_reset": "ctrl+0", "fullscreen": "F11",
}

def _run(argv, *, check=True, timeout=4):
    return subprocess.run(argv, check=check, timeout=timeout,
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def active_window():
    if not shutil.which("xdotool"):
        return None
    try:
        r = subprocess.run(["xdotool", "getactivewindow"], text=True, capture_output=True, check=True, timeout=2)
        return r.stdout.strip() if r.stdout.strip().isdigit() else None
    except (OSError, subprocess.SubprocessError):
        return None

def browser_is_active():
    """Firefox and Chromium tabs, but never the NovaOS home kiosk."""
    wid = active_window()
    if not wid:
        return False
    try:
        title = subprocess.run(["xdotool", "getwindowname", wid], text=True, capture_output=True,
                               check=True, timeout=2).stdout.casefold()
        if "novaos" in title and "home" in title:
            return False
        klass = subprocess.run(["xdotool", "getwindowclass", wid], text=True,
                               capture_output=True, check=True, timeout=2).stdout.casefold()
        return any(x in klass for x in ("firefox", "chromium", "chrome", "brave", "librewolf"))
    except (OSError, subprocess.SubprocessError):
        return False

def _xkey(key):
    if not shutil.which("xdotool"):
        raise ValueError("xdotool fehlt (benötigt für Fernbedienung).")
    _run(["xdotool", "key", "--clearmodifiers", key])

def _mouse(name):
    if not shutil.which("xdotool"):
        raise ValueError("xdotool fehlt (benötigt für Mausbedienung).")
    if name in ("mouse_left", "mouse_right"):
        _run(["xdotool", "click", "1" if name == "mouse_left" else "3"])
    elif name.startswith("cursor_"):
        dx, dy = {"cursor_left": (-55, 0), "cursor_right": (55, 0),
                  "cursor_up": (0, -55), "cursor_down": (0, 55)}[name]
        _run(["xdotool", "mousemove_relative", "--", str(dx), str(dy)])
    elif name.startswith("scroll_"):
        _run(["xdotool", "click", "4" if name == "scroll_up" else "5"])

def keyboard():
    app = shutil.which("onboard") or shutil.which("xvkbd")
    if not app:
        raise ValueError("Bildschirmtastatur fehlt (onboard/xvkbd).")
    args = [app] if app.endswith("onboard") else [app, "-compact"]
    subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    return "Bildschirmtastatur geöffnet"

def screenshot():
    if not shutil.which("xfce4-screenshooter"):
        raise ValueError("xfce4-screenshooter fehlt.")
    target = Path.home() / "Bilder" / "NovaOS"
    target.mkdir(parents=True, exist_ok=True)
    dest = target / f"bildschirmfoto-{time.strftime('%Y%m%d-%H%M%S')}.png"
    _run(["xfce4-screenshooter", "-f", "-s", str(dest)], timeout=15)
    return f"Bild gespeichert: {dest}"

def text_input(text):
    if not isinstance(text, str) or not text or len(text) > 160 or any(ord(c) < 32 for c in text):
        raise ValueError("Text muss 1–160 druckbare Zeichen enthalten.")
    if not shutil.which("xdotool"):
        raise ValueError("xdotool fehlt.")
    _run(["xdotool", "type", "--clearmodifiers", "--delay", "9", "--", text], timeout=10)
    return "Text eingegeben"

def perform_x11(name):
    """Return None for server-level actions (home, apps, volume, etc.)."""
    if name not in CONTROL_LABELS:
        raise ValueError("Unbekannte Steuerungsfunktion")
    if name in ("up", "down", "left", "right", "ok", "back"):
        if name in ("left", "right") and browser_is_active():
            _mouse("cursor_left" if name == "left" else "cursor_right")
            return "Mauszeiger horizontal bewegt"
        if name == "back" and not browser_is_active():
            _xkey("Escape")
        else:
            _xkey(KEYS[name])
        return "Navigation ausgeführt"
    if name in KEYS:
        _xkey(KEYS[name]); return "Tastenkombination ausgeführt"
    if name.startswith("cursor_") or name.startswith("mouse_") or name.startswith("scroll_"):
        _mouse(name); return "Maussteuerung ausgeführt"
    if name == "keyboard":
        return keyboard()
    if name == "screenshot":
        return screenshot()
    if name in ("play_pause", "next_track", "prev_track"):
        if not shutil.which("playerctl"):
            raise ValueError("playerctl fehlt.")
        _run(["playerctl", {"play_pause":"play-pause","next_track":"next","prev_track":"previous"}[name]])
        return "Mediensteuerung ausgeführt"
    return None
