"""LG MR20: Tastendruecke per evdev erkennen (Luftmaus bleibt beim Kernel).

Das Geraet wird absichtlich NICHT ge-grabbed: Maus, Scrollrad und Standardtasten
werden weiterhin direkt vom Linux-Desktop verarbeitet.
"""
from __future__ import annotations
import re
import shutil
import subprocess
import time
from pathlib import Path

# Nur Sondertasten, die NovaOS explizit bedienen soll. Richtung/OK erzeugen
# vom Kernel bereits normale HID-Events; doppelte Simulation vermeiden.
LG_DEFAULT_MAP = {
    "KEY_VOLUMEUP": "volup", "KEY_VOLUMEDOWN": "voldown",
    "KEY_MUTE": "mute", "KEY_HOMEPAGE": "home",
    "KEY_BACK": "back", "KEY_MENU": "launch_settings",
    "KEY_CONFIG": "launch_settings", "KEY_SETUP": "launch_settings",
    "KEY_POWER": "power_menu", "KEY_PLAYPAUSE": "play_pause",
    "KEY_NEXTSONG": "next_track", "KEY_PREVIOUSSONG": "prev_track",
}


def check_key_name(name: str) -> bool:
    return isinstance(name, str) and bool(re.fullmatch(r"KEY_[A-Z0-9_]{2,40}", name))


def lg_diagnostics():
    connected = False
    detected = False
    if shutil.which("bluetoothctl"):
        try:
            p = subprocess.run(["bluetoothctl", "devices"], capture_output=True,
                               text=True, timeout=3)
            for line in p.stdout.splitlines():
                if "LGE MR20" in line.upper():
                    detected = True
                    parts = line.split()
                    if len(parts) > 1:
                        i = subprocess.run(["bluetoothctl", "info", parts[1]],
                                           capture_output=True, text=True, timeout=3)
                        connected = "Connected: yes" in i.stdout
        except (OSError, subprocess.SubprocessError):
            pass
    return {"module_loaded": Path("/sys/module/lg_magic").exists(),
            "paired": detected, "connected": connected,
            "calibration": Path("/lib/firmware/lg_magic_calib.bin").is_file(),
            "driver_installed": bool(list(Path("/lib/modules").glob("*/updates/dkms/lg_magic.ko*"))) if Path("/lib/modules").exists() else False}


def lg_event_loop(callback, status):
    try:
        from evdev import InputDevice, list_devices, ecodes  # type: ignore
    except ImportError:
        status["message"] = "python3-evdev fehlt (wird mit NovaOS 4.1.1 installiert)"
        return
    while True:
        remote = None
        try:
            for path in list_devices():
                dev = InputDevice(path)
                if dev.name.strip() == "LG Magic Remote":
                    remote = dev
                    break
                dev.close()
            if remote is None:
                status["message"] = "LG Magic Remote nicht als Eingabegeraet erkannt"
                time.sleep(3)
                continue
            status["message"] = "LG Magic Remote erkannt: " + remote.path
            # Keine grab()-Sperre! Luftmaus und direkte Pfeiltasten bleiben nutzbar.
            for event in remote.read_loop():
                if event.type != ecodes.EV_KEY or event.value != 1:
                    continue
                name = ecodes.KEY.get(event.code)
                if isinstance(name, str) and check_key_name(name):
                    callback(name, event.value)
        except (OSError, PermissionError) as exc:
            status["message"] = "LG Eingabegeraet nicht lesbar: " + str(exc)
            time.sleep(3)
        except Exception as exc:
            status["message"] = "LG Eingabefehler: " + str(exc)
            time.sleep(3)
        finally:
            if remote is not None:
                try:
                    remote.close()
                except OSError:
                    pass
