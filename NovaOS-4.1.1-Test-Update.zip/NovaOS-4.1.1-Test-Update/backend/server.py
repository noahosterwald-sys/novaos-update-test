#!/usr/bin/env python3
"""NovaOS local TV shell and authenticated LAN remote. Standard-library first."""
from __future__ import annotations
import argparse
import configparser
import hmac
import ipaddress
import json
import mimetypes
import os
from pathlib import Path
import re
import secrets
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from controls import CONTROL_LABELS, CONTROL_GROUPS, KEYS, perform_x11, browser_is_active, text_input
from lg_remote import LG_DEFAULT_MAP, lg_event_loop, lg_diagnostics, check_key_name

ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / "web"
DATA_DIR = Path(os.getenv("NOVAOS_CONFIG_DIR", str(Path.home() / ".config" / "novaos")))
DATA_FILE = DATA_DIR / "state.json"
PORT = int(os.getenv("NOVAOS_PORT", "8765"))
WINDOWS = sys.platform.startswith("win")

APPLICATIONS = {
    "youtube": {"name": "YouTube", "url": "https://www.youtube.com/"},
    "twitch": {"name": "Twitch", "url": "https://www.twitch.tv/"},
    "spotify": {"name": "Spotify", "url": "https://open.spotify.com/"},
    "ard": {"name": "ARD Mediathek", "url": "https://www.ardmediathek.de/"},
    "zdf": {"name": "ZDF", "url": "https://www.zdf.de/"},
    "radio": {"name": "Internetradio", "url": "https://www.radio-browser.info/"},
    "firefox": {"name": "Firefox", "command": ["firefox-esr"], "fallback": "https://www.mozilla.org/firefox/"},
    "vlc": {"name": "VLC", "command": ["vlc"]},
    "kodi": {"name": "Kodi", "command": ["kodi"]},
    "jellyfin": {"name": "Jellyfin", "url": "https://jellyfin.org/"},
    "files": {"name": "Dateien", "command": ["thunar"]},
    "terminal": {"name": "Terminal", "command": ["xfce4-terminal"]},
    "arduino": {"name": "Arduino IDE", "command": ["arduino"]},
    "display": {"name": "Bildschirm", "command": ["arandr"]},
    "bluetooth": {"name": "Bluetooth", "command": ["blueman-manager"]},
    "mirror": {"name": "Handy per USB spiegeln", "command": ["/usr/local/bin/novaos-phone-mirror"]},
    "help": {"name": "Hilfe & erster Start", "url": "http://127.0.0.1:8765/help"},
    "setup": {"name": "NovaOS Ersteinrichtung", "url": "http://127.0.0.1:8765/setup"},
    "diagnose": {"name": "NovaOS Diagnose", "command": ["xfce4-terminal", "--hold", "--command=/usr/local/bin/novaos-diagnose"]},
    "appstore": {"name": "App-Center", "command": ["gnome-software"]},
    "android": {"name": "Android-Unterstützung (Experiment)", "command": ["/usr/local/bin/novaos-android-test"]},
    "audio": {"name": "Audioeinstellungen", "command": ["pavucontrol"]},
    "lg_setup": {"name": "LG Magic Remote einrichten", "command": ["/usr/local/bin/novaos-lg-gui-setup"]},
    "settings": {"name": "Einstellungen", "internal": "settings"},
    "install": {"name": "NovaOS auf Festplatte installieren", "command": ["/usr/local/bin/novaos-install"]},
    "updates": {"name": "System-Updates", "command": ["gnome-software"]},
    "nova_update": {"name": "NovaOS Update-Center", "command": ["/usr/local/bin/novaos-update-center"]},
}
ACTIONS = set(CONTROL_LABELS)
# Nur freigegebene Pakete, keine beliebigen Shell-Befehle via Browser.
SOFTWARE_CATALOG = {
    "gimp": ("GIMP – Bildbearbeitung", "gimp"),
    "libreoffice": ("LibreOffice – Office", "libreoffice"),
    "audacity": ("Audacity – Audioeditor", "audacity"),
    "chromium": ("Chromium – Browser", "chromium"),
    "inkscape": ("Inkscape – Vektorgrafik", "inkscape"),
    "kdenlive": ("Kdenlive – Videoeditor", "kdenlive"),
    "gparted": ("GParted – Partitionen", "gparted"),
    "htop": ("htop – Systemmonitor", "htop"),
}


# Blaupunkt Originalfernbedienung – am Arduino Uno R3 gemessen.
# NEC-Protokoll, Adresse 0x7F00, IRremote 4.x via USB-Serial.
# Nutzerdefinierte Belegungen aus state.json haben Vorrang.
BLAUPUNKT_IR_DEFAULTS = {
    "IR:NEC:7F00:5E": "up",
    "IR:NEC:7F00:56": "down",
    "IR:NEC:7F00:5B": "left",
    "IR:NEC:7F00:58": "right",
    "IR:NEC:7F00:5A": "ok",
    "IR:NEC:7F00:4E": "back",
    "IR:NEC:7F00:1E": "volup",
    "IR:NEC:7F00:5F": "voldown",
    "IR:NEC:7F00:57": "home",
}


def load_state():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    try:
        state = json.loads(DATA_FILE.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        state = {}
    state.setdefault("pair_pin", f"{secrets.randbelow(1000000):06d}")
    state.setdefault("remote_token", secrets.token_urlsafe(32))
    state.setdefault("ir_map", {})
    state.setdefault("jellyfin_url", "")
    state.setdefault("browser_arrows_mouse", True)
    state.setdefault("key_hints", True)
    state.setdefault("lg_map", {})
    return state


LOCK = threading.RLock()
STATE = load_state()
FAILED_PAIRS = {}
LAST_IR = {"code": "", "when": 0, "port": "", "message": "Warte auf Arduino"}
LAST_KEY = {"seq": 0, "code": "", "action": "", "port": "", "when": 0}
PENDING_IR = None
LAST_HOME_PRESS = 0.0
PENDING_LG = None
LAST_LG = {"code": "", "when": 0, "message": "Warte auf LG Magic Remote"}


def save_state():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temp = DATA_FILE.with_suffix(".tmp")
    temp.write_text(json.dumps(STATE, ensure_ascii=False, indent=2), encoding="utf-8")
    os.chmod(temp, 0o600)
    temp.replace(DATA_FILE)


save_state()


def run_command(command):
    """Launch a desktop app and preserve diagnostics for programs that exit."""
    try:
        log_dir = Path.home() / ".cache"
        log_dir.mkdir(parents=True, exist_ok=True)
        with (log_dir / "novaos-apps.log").open("ab") as log:
            log.write(("\n[NovaOS] Starte: " + command[0] + "\n").encode())
            proc = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT,
                                    start_new_session=(os.name != "nt"))
            # A fast, nonzero exit is a genuine launch failure, not a success.
            try:
                code = proc.wait(timeout=0.25)
                if code != 0:
                    raise ValueError(f"Programm konnte nicht starten (Exit {code}). Details: ~/.cache/novaos-apps.log")
            except subprocess.TimeoutExpired:
                pass
            return proc
    except (OSError, ValueError) as exc:
        raise ValueError(f"Programm konnte nicht gestartet werden: {exc}") from exc


def hide_home_window():
    """Minimize only the NovaOS TV window, not another active app.

    The UI runs in a separate Firefox profile. Searching for its window
    title keeps remote-triggered launches from minimizing unrelated apps.
    """
    if WINDOWS or not shutil.which('wmctrl'):
        return
    try:
        windows = subprocess.run(['wmctrl', '-l'], capture_output=True,
                                 text=True, timeout=2, check=True).stdout
        for line in windows.splitlines():
            fields = line.split(maxsplit=3)
            if len(fields) == 4 and 'NovaOS' in fields[3] and 'Home' in fields[3]:
                subprocess.run(['xdotool', 'windowminimize', fields[0]],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                               timeout=2, check=False)
                return
    except (OSError, subprocess.SubprocessError):
        pass


def is_live_system():
    if WINDOWS:
        return False
    try:
        return "boot=live" in Path("/proc/cmdline").read_text()
    except OSError:
        return False


def open_url(url):
    try:
        parsed = urllib.parse.urlsplit(url)
        if parsed.scheme not in {"https", "http"} or not parsed.hostname or parsed.username or parsed.password:
            raise ValueError("Es sind nur gültige HTTP-/HTTPS-Adressen erlaubt.")
        if len(url) > 2000:
            raise ValueError("Adresse ist zu lang.")
    except ValueError as exc:
        raise ValueError("Ungültiger Link") from exc
    if WINDOWS:
        webbrowser.open(url, new=2)
    else:
        browser = "firefox-esr" if shutil.which("firefox-esr") else "firefox"
        if not shutil.which(browser):
            raise ValueError("Firefox ist nicht installiert.")
        hide_home_window()
        # Nova Home is a --no-remote Firefox instance with its own private
        # profile. Open streaming sites in the normal Firefox instance so
        # subsequent app launches can reuse it instead of hitting a locked
        # custom --profile directory.
        run_command([browser, "--new-window", url])


def open_firefox_blank():
    browser = "firefox-esr" if shutil.which("firefox-esr") else "firefox"
    if not shutil.which(browser):
        raise ValueError("Firefox ist nicht installiert")
    hide_home_window()
    run_command([browser, "--new-window", "about:blank"])
    return "Firefox gestartet"


def open_app(app_id):
    if app_id not in APPLICATIONS:
        raise ValueError("Unbekannte App")
    app = APPLICATIONS[app_id]
    if app_id == "jellyfin" and STATE.get("jellyfin_url"):
        open_url(STATE["jellyfin_url"])
        return "Jellyfin gestartet"
    if "url" in app:
        open_url(app["url"])
        return f"{app['name']} geöffnet"
    if "command" in app:
        command = app["command"]
        if app_id == "firefox" and not WINDOWS:
            return open_firefox_blank()
        if WINDOWS and app.get("fallback"):
            open_url(app["fallback"])
            return f"{app['name']} im Browser geöffnet"
        if not shutil.which(command[0]):
            raise ValueError(f"{app['name']} ist noch nicht installiert.")
        hide_home_window()
        run_command(command)
        return f"{app['name']} gestartet"
    return "Einstellungen im NovaOS-Startbildschirm öffnen"


def desktop_apps():
    """Nur vorhandene .desktop-Dateien; kein Shell-Befehl aus der Weboberflaeche."""
    items = {}
    dirs = [Path('/usr/share/applications'), Path.home() / '.local/share/applications']
    for directory in dirs:
        if not directory.is_dir():
            continue
        for fp in directory.glob('*.desktop'):
            desktop_id = fp.name[:-8]
            if not re.fullmatch(r'[A-Za-z0-9_.-]{1,100}', desktop_id):
                continue
            parser = configparser.ConfigParser(interpolation=None, strict=False)
            try:
                parser.read(fp, encoding='utf-8')
                section = parser['Desktop Entry']
                if section.get('Type','') != 'Application' or section.get('NoDisplay','false').lower() == 'true' or section.get('Hidden','false').lower() == 'true':
                    continue
                label = section.get('Name[de]', section.get('Name','')).strip()
                if not label or not section.get('Exec','').strip():
                    continue
                items[desktop_id] = {'id':desktop_id, 'name':label[:80]}
            except (OSError, UnicodeError, configparser.Error, KeyError):
                continue
    return sorted(items.values(), key=lambda item: item['name'].casefold())[:250]


def launch_desktop_app(desktop_id):
    installed = {item['id'] for item in desktop_apps()}
    if desktop_id not in installed:
        raise ValueError('Programm ist nicht mehr installiert oder ungueltig')
    if not shutil.which('gtk-launch'):
        raise ValueError('gtk-launch fehlt (libgtk-3-bin).')
    hide_home_window()
    run_command(['gtk-launch', desktop_id])
    return 'Programm gestartet'


def audio_outputs():
    if WINDOWS or not shutil.which("pactl"):
        return {"outputs": [], "default": "", "status": "Audiogeräte nur unter Linux verfügbar"}
    try:
        default = subprocess.run(["pactl", "get-default-sink"], capture_output=True,
                                 text=True, timeout=3, check=True).stdout.strip()
        result = subprocess.run(["pactl", "list", "short", "sinks"], capture_output=True,
                                text=True, timeout=3, check=True).stdout
        rows = []
        for line in result.splitlines():
            cols = line.split("\t")
            if len(cols) >= 2:
                name = cols[1]
                category = "HDMI / DisplayPort" if "hdmi" in name.lower() else (
                    "Analog / AUX" if "analog" in name.lower() else "Audio")
                rows.append({"id": name, "label": f"{category} · {name}"})
        return {"outputs": rows, "default": default, "status": "OK"}
    except (OSError, subprocess.SubprocessError):
        return {"outputs": [], "default": "", "status": "Audiodienst nicht erreichbar"}


def set_audio(sink):
    sinks = audio_outputs()
    if sink not in {item["id"] for item in sinks["outputs"]}:
        raise ValueError("Audiogerät wurde nicht gefunden")
    subprocess.run(["pactl", "set-default-sink", sink], check=True, timeout=5)
    # Move already-playing applications, not only future audio streams.
    try:
        active = subprocess.run(["pactl", "list", "short", "sink-inputs"], text=True,
                                capture_output=True, check=True, timeout=3).stdout
        for line in active.splitlines():
            stream_id = line.split("\t", 1)[0]
            if stream_id.isdigit():
                subprocess.run(["pactl", "move-sink-input", stream_id, sink], timeout=3,
                               check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except (OSError, subprocess.SubprocessError):
        pass
    return "Audioausgang gewechselt (auch laufende Apps)"


def tv_mode():
    if WINDOWS:
        webbrowser.open(f"http://127.0.0.1:{PORT}/", new=1)
        return "Nova Home geöffnet"
    if shutil.which("wmctrl"):
        result = subprocess.run(["wmctrl", "-a", "NovaOS · Home"], stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL, timeout=3)
        if result.returncode == 0:
            return "Nova Home aktiviert"
    path = "/usr/local/bin/novaos-tv"
    if Path(path).is_file():
        run_command([path])
    else:
        open_url(f"http://127.0.0.1:{PORT}/")
    return "Nova Home geöffnet"


def desktop_mode():
    if WINDOWS:
        return "Unter Windows ist der Desktop bereits aktiv"
    if shutil.which("xdotool"):
        hide_home_window()
        return "Desktop-Modus aktiviert"
    raise ValueError("xdotool fehlt; Desktop-Wechsel nicht verfügbar")


def send_key(action):
    if action not in {"up", "down", "left", "right", "ok", "back"}:
        raise ValueError("Ungültige Navigationstaste")
    if WINDOWS:
        return "Eingabe nur im Linux-Desktop verfügbar"
    if action in ("left", "right") and not STATE.get("browser_arrows_mouse", True):
        if not shutil.which("xdotool"):
            raise ValueError("xdotool fehlt")
        subprocess.run(["xdotool", "key", "--clearmodifiers", KEYS[action]], check=True, timeout=3)
        return "Navigation ausgeführt"
    return perform_x11(action)


def keymap_window():
    """Show the current mapping without reinstalling NovaOS or changing focus permanently.

    On the XFCE desktop and while browsing, zenity displays the complete list.
    In Nova Home, the dedicated F1 shortcut uses the styled browser overlay.
    """
    if WINDOWS:
        return "Tastenübersicht: Öffne NovaOS und drücke F1"
    if nova_home_is_active() and shutil.which("xdotool"):
        subprocess.run(["xdotool", "key", "F1"], timeout=3, check=False)
        return "Tastenübersicht in Nova Home geöffnet"
    if not shutil.which("zenity"):
        tv_mode()
        if shutil.which("xdotool"):
            time.sleep(0.2)
            subprocess.run(["xdotool", "key", "F1"], timeout=3, check=False)
        return "Tastenübersicht geöffnet"
    lines = ["NOVAOS 4.0 – TASTENÜBERSICHT", "", "BLAUPUNKT-FERNBEDIENUNG", ""]
    fixed_names = {"5E": "Hoch", "56": "Runter", "5B": "Links", "58": "Rechts",
                   "5A": "OK", "4E": "Exit / Zurück", "1E": "Lautstärke +",
                   "5F": "Lautstärke -", "57": "Menü / Home"}
    with LOCK:
        assignments = {**BLAUPUNKT_IR_DEFAULTS, **STATE["ir_map"]}
    for ir_code, action in assignments.items():
        key = ir_code.split(":")[-1]
        hint = fixed_names.get(key, "Taste 0x" + key)
        lines.append(f"{hint:<20}  →  {CONTROL_LABELS.get(action, action)}")
    lines.extend(["", "Tasten 1 und 2: im Anlernmenü als Linksklick und Rechtsklick belegen.",
                  "Im Browser: Links/Rechts bewegt den Mauszeiger, wenn aktiviert.",
                  "", "ALLE VERFÜGBAREN FUNKTIONEN", ""])
    for category, items in CONTROL_GROUPS.items():
        lines.extend(["", category.upper()])
        lines.extend("  " + desc for desc in items.values())
    path = DATA_DIR / "tastenuebersicht.txt"
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    subprocess.Popen(["zenity", "--text-info", "--title=NovaOS: Fernbedienung – Tastenübersicht",
                      "--filename=" + str(path), "--width=820", "--height=650"],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    return "Tastenübersicht geöffnet"


def nova_home_is_active():
    if not shutil.which("xdotool"):
        return False
    try:
        wid = subprocess.run(["xdotool", "getactivewindow"], text=True,
                             capture_output=True, check=True, timeout=2).stdout.strip()
        title = subprocess.run(["xdotool", "getwindowname", wid], text=True,
                               capture_output=True, check=True, timeout=2).stdout.casefold()
        return "novaos" in title and "home" in title
    except (OSError, subprocess.SubprocessError):
        return False


def record_key_press(code, action, port):
    with LOCK:
        LAST_KEY.update(seq=LAST_KEY["seq"] + 1, code=code, action=action or "",
                        port=port, when=int(time.time()))
    # XFCE displays short hints even when Firefox, VLC or the Desktop is focused.
    # Throttle held buttons to avoid flooding the notification daemon.
    if not WINDOWS and action and action != "show_keys" and STATE.get("key_hints", True):
        now = time.monotonic()
        last = getattr(record_key_press, "last_toast", 0.0)
        if now - last > 0.9 and not nova_home_is_active() and shutil.which("notify-send"):
            record_key_press.last_toast = now
            try:
                label = CONTROL_LABELS.get(action, action)
                if action in {"left", "right"} and STATE.get("browser_arrows_mouse", True):
                    label = "Mauszeiger " + ("links" if action == "left" else "rechts")
                subprocess.Popen(["notify-send", "-t", "1400", "-a", "NovaOS Fernbedienung",
                                  "Taste 0x" + code.split(":")[-1], label],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
            except OSError:
                pass


def dispatch_control(name):
    if name not in CONTROL_LABELS:
        raise ValueError("Unbekannte Steuerungsfunktion")
    if name in ("up", "down", "left", "right", "ok", "back"):
        return send_key(name)
    if name == "show_keys":
        return keymap_window()
    if name == "power_menu":
        return power_menu()
    if name == "launch_appstore":
        return open_app("appstore")
    if name in ("home", "desktop"):
        return execute_action(name)
    if name in ("volup", "voldown", "mute"):
        return execute_action("volume", {"direction": {"volup": "up", "voldown": "down", "mute": "mute"}[name]})
    if name.startswith("launch_"):
        app = name[7:]
        if app == "settings":
            tv_mode()
            if not WINDOWS and shutil.which("xdotool"):
                subprocess.run(["xdotool", "key", "F2"], check=False, timeout=3)
            return "NovaOS Einstellungen geöffnet"
        return open_app(app)
    if name == "search":
        if WINDOWS:
            return "Suchfeld unter Linux verfügbar"
        if not shutil.which("xdotool"):
            raise ValueError("xdotool fehlt")
        subprocess.run(["xdotool", "key", "--clearmodifiers", "ctrl+l" if browser_is_active() else "slash"], check=True, timeout=3)
        return "Suche geöffnet"
    if WINDOWS:
        return "Steuerung benötigt Linux/X11"
    return perform_x11(name)


def power_menu():
    """Eine Aktion anfordern, NICHT ohne sichtbare Bestätigung ausschalten."""
    if WINDOWS:
        raise ValueError("Ausschaltmenü nur unter Linux verfügbar")
    if not shutil.which("zenity"):
        raise ValueError("zenity fehlt. Bitte installieren, damit das Ausschalten bestätigt wird.")
    # Kein direkter Netzwerkbefehl für poweroff/reboot; nur ein lokaler Dialog.
    def worker():
        try:
            selected = subprocess.run(
                ["zenity", "--list", "--radiolist", "--title=NovaOS 4.1.1 – Energie",
                 "--text=Was möchtest du tun? Bitte auswählen und bestätigen.",
                 "--column=", "--column=Aktion", "TRUE", "Abbrechen",
                 "FALSE", "Herunterfahren", "FALSE", "Neustarten",
                 "--width=420", "--height=290"],
                text=True, capture_output=True, timeout=180)
            if selected.returncode != 0:
                return
            action = selected.stdout.strip()
            if action == "Herunterfahren":
                subprocess.run(["loginctl", "poweroff"], check=False, timeout=10)
            elif action == "Neustarten":
                subprocess.run(["loginctl", "reboot"], check=False, timeout=10)
        except (OSError, subprocess.SubprocessError):
            pass
    threading.Thread(target=worker, name="novaos-power-confirm", daemon=True).start()
    return "Ausschaltmenü auf dem Fernseher geöffnet – bitte dort bestätigen"


def software_install(package_id):
    if package_id not in SOFTWARE_CATALOG:
        raise ValueError("Programm ist nicht im geprüften App-Katalog")
    launcher = "/usr/local/bin/novaos-app-install"
    if not Path(launcher).is_file():
        raise ValueError("App-Installer fehlt. NovaOS 4.1.1 vollständig installieren.")
    if not shutil.which("xfce4-terminal"):
        raise ValueError("XFCE-Terminal fehlt")
    # Nur die feste ID an einen geprüften Installer übergeben.
    run_command(["xfce4-terminal", "--hold", "--command=" + launcher + " " + package_id])
    return SOFTWARE_CATALOG[package_id][0] + ": Installation gestartet; Passwortdialog beachten"


def lg_event(name, value):
    """LG-Tasten aus dem evdev-Leser. Pfeile / OK bleiben native HID-Eingaben."""
    global PENDING_LG
    if value != 1 or not check_key_name(name):
        return
    with LOCK:
        if PENDING_LG:
            STATE["lg_map"][name] = PENDING_LG
            save_state()
            LAST_LG.update(code=name, when=int(time.time()), message="Taste " + name + " belegt")
            PENDING_LG = None
            return
        action = STATE.get("lg_map", {}).get(name, LG_DEFAULT_MAP.get(name))
    LAST_LG.update(code=name, when=int(time.time()), message="Taste " + name + " erkannt")
    if action:
        try:
            dispatch_control(action)
        except (OSError, ValueError, subprocess.SubprocessError) as exc:
            LAST_LG["message"] = str(exc)


def touchpad_move(payload):
    """Authenticated phone touchpad: bounded, pixel-precise X11 relative move."""
    dx, dy = payload.get("dx"), payload.get("dy")
    if type(dx) is not int or type(dy) is not int:
        raise ValueError("Touchpad: dx/dy muessen ganze Zahlen sein")
    if abs(dx) > 160 or abs(dy) > 160:
        raise ValueError("Touchpad: Bewegung zu gross")
    if WINDOWS:
        raise ValueError("Touchpad benoetigt NovaOS auf Linux")
    if not shutil.which("xdotool"):
        raise ValueError("xdotool fehlt fuer die Touchpad-Steuerung")
    if dx == 0 and dy == 0:
        return "Touchpad bereit"
    subprocess.run(["xdotool", "mousemove_relative", "--", str(dx), str(dy)],
                   check=True, timeout=3)
    return "Mauszeiger bewegt"


def execute_action(action, payload=None, *, local=False):
    payload = payload or {}
    if action == "power_menu":
        return power_menu()
    if action == "launch_desktop_app":
        if not local:
            raise ValueError("Lokale Programme nur direkt auf NovaOS starten")
        return launch_desktop_app(str(payload.get("id", "")))
    if action == "install_software":
        if not local:
            raise ValueError("Softwareinstallation nur direkt auf dem NovaOS-Rechner")
        return software_install(str(payload.get("package", "")))
    if action == "lg_setup":
        if not local:
            raise ValueError("LG-Einrichtung nur direkt auf dem NovaOS-Rechner")
        return open_app("lg_setup")
    if action == "lg_learn":
        if not local:
            raise ValueError("LG-Tastenbelegung nur direkt auf NovaOS")
        name = str(payload.get("name", ""))
        if name not in ACTIONS:
            raise ValueError("Ungültige Tastenfunktion")
        global PENDING_LG
        with LOCK:
            PENDING_LG = name
        return "Drücke jetzt die gewünschte LG-Taste (nicht Mausbewegung)"
    if action == "lg_reset":
        if not local:
            raise ValueError("LG-Tastenbelegung nur direkt auf NovaOS")
        with LOCK:
            STATE["lg_map"] = {}
            save_state()
        return "LG-Tastenbelegung zurückgesetzt"
    if action == "app":
        app_id = str(payload.get("id", ""))
        if app_id == "nova_update" and not local:
            raise ValueError("Update-Center nur direkt auf NovaOS öffnen")
        if app_id == "install":
            if not local:
                raise ValueError("Der Installer kann nur direkt am Lenovo gestartet werden.")
            if not is_live_system():
                raise ValueError("NovaOS läuft bereits von einer installierten Festplatte. Der Installer ist nur im Live-Modus verfügbar.")
        return open_app(app_id)
    if action == "open_url":
        open_url(str(payload.get("url", "")))
        return "Link geöffnet"
    if action == "tv" or action == "home":
        return tv_mode()
    if action == "desktop":
        return desktop_mode()
    if action == "volume":
        direction = payload.get("direction", "")
        if direction not in {"up", "down", "mute"}:
            raise ValueError("Ungültige Lautstärkeaktion")
        if not shutil.which("pactl"):
            raise ValueError("Audiosteuerung noch nicht verfügbar")
        cmd = (["pactl", "set-sink-mute", "@DEFAULT_SINK@", "toggle"] if direction == "mute" else
               ["pactl", "set-sink-volume", "@DEFAULT_SINK@", "+5%" if direction == "up" else "-5%"])
        subprocess.run(cmd, check=True, timeout=3)
        return "Lautstärke geändert"
    if action == "audio_output":
        return set_audio(str(payload.get("sink", "")))
    if action == "key":
        return send_key(str(payload.get("key", "")))
    if action == "control":
        return dispatch_control(str(payload.get("name", "")))
    if action == "touchpad_move":
        return touchpad_move(payload)
    if action == "text":
        if WINDOWS:
            raise ValueError("Handy-Texteingabe nur unter Linux")
        return text_input(payload.get("text"))
    if action == "key_hints":
        enabled = payload.get("enabled")
        if not isinstance(enabled, bool):
            raise ValueError("Ungültige Einstellung")
        with LOCK:
            STATE["key_hints"] = enabled
            save_state()
        return "Tastenhinweise " + ("aktiviert" if enabled else "ausgeschaltet")
    if action == "browser_arrows_mouse":
        enabled = payload.get("enabled")
        if not isinstance(enabled, bool):
            raise ValueError("Ungültige Einstellung")
        with LOCK:
            STATE["browser_arrows_mouse"] = enabled
            save_state()
        return "Browser-Pfeiltasten: " + ("Mauszeiger" if enabled else "normale Navigation")
    if action == "ir_learn":
        kind = payload.get("key", "")
        if kind not in ACTIONS:
            raise ValueError("Ungültige IR-Taste")
        global PENDING_IR
        with LOCK:
            PENDING_IR = kind
        return f"Lernmodus aktiv: Taste '{kind}' auf der Blaupunkt-Fernbedienung drücken"
    if action == "ir_clear":
        with LOCK:
            STATE["ir_map"] = {}
            save_state()
        return "Eigene IR-Belegung gelöscht; Blaupunkt-Standard bleibt erhalten"
    if action == "save_jellyfin":
        url = str(payload.get("url", "")).strip()
        if url:
            parsed = urllib.parse.urlsplit(url)
            if parsed.scheme not in {"http", "https"} or not parsed.hostname:
                raise ValueError("Ungültige Jellyfin-Adresse")
        with LOCK:
            STATE["jellyfin_url"] = url
            save_state()
        return "Jellyfin-Adresse gespeichert"
    raise ValueError("Unbekannte Aktion")


def available_ip():
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(1)
        sock.connect(("1.1.1.1", 53))
        ip = sock.getsockname()[0]
        sock.close()
        return ip
    except OSError:
        try:
            return socket.gethostbyname(socket.gethostname())
        except OSError:
            return "127.0.0.1"


def handle_ir_code(code, port):
    global PENDING_IR
    code = code.strip()
    # Unterstützt das alte Zahlenformat und das neue, lesbare NEC-Format.
    if not re.fullmatch(r"IR:(?:NEC|[0-9A-Fa-f]{1,4}):[0-9A-Fa-f]{1,8}:[0-9A-Fa-f]{1,8}", code, flags=re.IGNORECASE):
        return
    code = code.upper()  # Einheitliche Großschreibung für Adresse und IR-Befehl.
    with LOCK:
        LAST_IR.update({"code": code, "when": int(time.time()), "port": port,
                        "message": "IR-Signal erkannt"})
        if PENDING_IR:
            STATE["ir_map"][code] = PENDING_IR
            LAST_IR["message"] = f"Angelernt: {PENDING_IR}"
            PENDING_IR = None
            save_state()
            return
        action = STATE["ir_map"].get(code) or BLAUPUNKT_IR_DEFAULTS.get(code)
    # Two quick presses of the original MENÜ/Home key open the map without
    # requiring any new Arduino sketch or a spare IR button.
    global LAST_HOME_PRESS
    if action == "home":
        now = time.monotonic()
        if now - LAST_HOME_PRESS <= 0.85:
            action = "show_keys"
            LAST_HOME_PRESS = 0.0
        else:
            LAST_HOME_PRESS = now
    elif action:
        LAST_HOME_PRESS = 0.0
    record_key_press(code, action, port)
    if action:
        try:
            # All mappings, including the 9 original ones, use the same safe dispatcher.
            dispatch_control(action)
        except (ValueError, OSError, subprocess.SubprocessError) as exc:
            LAST_IR["message"] = str(exc)


def ir_loop():
    try:
        import serial  # type: ignore
    except ImportError:
        LAST_IR["message"] = "Python-Modul pyserial fehlt (apt install python3-serial)"
        return
    import glob
    while True:
        # Prefer stable Arduino USB identity; avoid probing unrelated serial modems.
        candidates = sorted(glob.glob("/dev/serial/by-id/*"))
        arduino_ids = [p for p in candidates if "arduino" in p.casefold() or "0043" in p]
        ports = arduino_ids or sorted(set(glob.glob("/dev/ttyACM*") + glob.glob("/dev/ttyUSB*")))
        if not ports:
            LAST_IR["message"] = "Kein Arduino angeschlossen"
            time.sleep(4)
            continue
        for port in ports:
            try:
                with serial.Serial(port, 115200, timeout=2) as ser:
                    LAST_IR["message"] = f"Arduino verbunden: {port}"
                    while True:
                        data = ser.readline().decode("ascii", errors="ignore").strip()
                        if data.startswith("IR:"):
                            handle_ir_code(data, port)
            except (OSError, serial.SerialException):
                continue
        time.sleep(3)


class NovaHandler(BaseHTTPRequestHandler):
    server_version = "NovaOS/4.1.1"

    def log_message(self, fmt, *args):
        print("[NovaOS]", self.address_string(), fmt % args)

    def local(self):
        try:
            return ipaddress.ip_address(self.client_address[0]).is_loopback
        except ValueError:
            return False

    def authorized(self):
        token = self.headers.get("Authorization", "").removeprefix("Bearer ").strip()
        with LOCK:
            return self.local() or (bool(token) and hmac.compare_digest(token, STATE["remote_token"]))

    def respond(self, status, data):
        encoded = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(encoded)

    def local_check(self):
        """Non-destructive checks for the first-run page, local browser only."""
        import glob
        apps = {name: bool(shutil.which(command)) for name, command in {
            "Firefox": "firefox-esr", "VLC": "vlc", "Kodi": "kodi",
            "App-Center": "gnome-software", "Arduino IDE": "arduino",
            "Bildschirmtastatur": "onboard", "Maussteuerung": "xdotool",
            "Dateimanager": "thunar", "Netzwerkmanager": "nmcli",
            "Installer": "calamares"
        }.items()}
        usb = sorted(glob.glob('/dev/serial/by-id/*'))
        return {"version":"4.1.1", "apps":apps,
                "display":bool(os.getenv('DISPLAY')),
                "audio":audio_outputs(),
                "arduino_devices":[Path(item).name for item in usb if 'arduino' in item.casefold() or '0043' in item],
                "lg_remote":lg_diagnostics(), "live":is_live_system(), "ip":available_ip(), "port":PORT}

    def do_GET(self):
        route = urllib.parse.urlsplit(self.path).path
        if route == '/api/check':
            if not self.local():
                self.respond(403, {"error": "Diagnose nur auf diesem PC"})
                return
            self.respond(200, self.local_check())
            return
        if route in {"/api/health", "/api/status"}:
            self.respond(200, {"ok": True, "name": "NovaOS", "version": "4.1.1", "hostname": socket.gethostname(),
                               "ip": available_ip(), "port": PORT, "local": self.local(), "live": is_live_system()})
            return
        if route == "/api/local":
            if not self.local():
                self.respond(403, {"error": "Nur am Fernseher sichtbar"})
                return
            self.respond(200, {"pin": STATE["pair_pin"], "url": f"http://{available_ip()}:{PORT}/remote"})
            return
        if route == "/api/key-event":
            if not self.local():
                self.respond(403, {"error": "Nur direkt an NovaOS abrufbar"})
                return
            with LOCK:
                self.respond(200, {**LAST_KEY, "enabled": STATE.get("key_hints", True)})
            return
        if route in {"/api/audio", "/api/ir", "/api/controls", "/api/lg", "/api/software", "/api/desktop-apps"}:
            if not self.authorized():
                self.respond(401, {"error": "Bitte Fernbedienung koppeln"})
                return
            if route == "/api/audio":
                self.respond(200, audio_outputs())
            elif route == "/api/desktop-apps":
                if not self.local():
                    self.respond(403, {"error":"Nur direkt auf NovaOS"})
                    return
                self.respond(200, {"apps": desktop_apps()})
            elif route == "/api/software":
                if not self.local():
                    self.respond(403, {"error":"Nur direkt auf NovaOS"})
                    return
                self.respond(200, {"apps":[{"id":k,"name":v[0]} for k,v in SOFTWARE_CATALOG.items()]})
            elif route == "/api/lg":
                if not self.local():
                    self.respond(403, {"error":"Nur direkt auf NovaOS"})
                    return
                with LOCK:
                    data = {"last":LAST_LG.copy(),"pending":PENDING_LG,
                            "map":{**LG_DEFAULT_MAP, **STATE.get("lg_map",{})}}
                self.respond(200, {**data, **lg_diagnostics()})
            elif route == "/api/controls":
                self.respond(200, {"groups": CONTROL_GROUPS, "count": len(CONTROL_LABELS),
                                   "browser_arrows_mouse": STATE.get("browser_arrows_mouse", True),
                                   "key_hints": STATE.get("key_hints", True)})
            else:
                with LOCK:
                    self.respond(200, {"last": LAST_IR.copy(), "pending": PENDING_IR,
                                       "map": {**BLAUPUNKT_IR_DEFAULTS, **STATE["ir_map"]},
                                       "jellyfin_url": STATE["jellyfin_url"],
                                       "browser_arrows_mouse": STATE.get("browser_arrows_mouse", True)})
            return
        # Limit served files to the static web directory.
        if route == "/":
            route = "/index.html"
        elif route == "/remote":
            route = "/remote.html"
        elif route == "/help":
            route = "/help.html"
        elif route == "/setup":
            route = "/setup.html"
        safe = (WEB / route.lstrip("/")).resolve()
        if not safe.is_relative_to(WEB) or not safe.is_file():
            self.send_error(404)
            return
        data = safe.read_bytes()
        self.send_response(200)
        mime = mimetypes.guess_type(safe.name)[0] or "application/octet-stream"
        self.send_header("Content-Type", mime + ("; charset=utf-8" if mime.startswith("text/") or mime == "application/javascript" else ""))
        self.send_header("Content-Length", str(len(data)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        path = urllib.parse.urlsplit(self.path).path
        if path not in {"/api/pair", "/api/action"}:
            self.respond(404, {"error": "Unbekannter Endpunkt"})
            return
        origin = self.headers.get("Origin", "")
        if origin:
            parsed_origin = urllib.parse.urlsplit(origin)
            if parsed_origin.scheme not in {"http", "https"} or parsed_origin.netloc != self.headers.get("Host", ""):
                self.respond(403, {"error": "Fremde Webseite darf NovaOS nicht steuern"})
                return
        if self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower() != "application/json":
            self.respond(415, {"error": "Nur JSON-Anfragen erlaubt"})
            return
        size = self.headers.get("Content-Length", "")
        if not size.isdigit() or int(size) > 8192:
            self.respond(413, {"error": "Ungültige Datenmenge"})
            return
        try:
            obj = json.loads(self.rfile.read(int(size)))
            if not isinstance(obj, dict):
                raise ValueError()
        except (json.JSONDecodeError, ValueError, UnicodeDecodeError):
            self.respond(400, {"error": "Ungültiges JSON"})
            return
        if path == "/api/pair":
            remote_addr = self.client_address[0]
            count, start = FAILED_PAIRS.get(remote_addr, (0, 0))
            if count >= 5 and (time.monotonic() - start) < 60:
                self.respond(429, {"error": "Zu viele Versuche. Bitte 1 Minute warten."})
                return
            entered_pin = str(obj.get("pin", ""))
            with LOCK:
                correct = hmac.compare_digest(entered_pin, STATE["pair_pin"])
                token = STATE["remote_token"] if correct else ""
            if correct:
                FAILED_PAIRS.pop(remote_addr, None)
                self.respond(200, {"ok": True, "token": token})
            else:
                FAILED_PAIRS[remote_addr] = (count + 1 if time.monotonic() - start < 60 else 1, time.monotonic())
                self.respond(401, {"error": "Falscher Kopplungscode"})
            return
        if not self.authorized():
            self.respond(401, {"error": "Fernbedienung nicht gekoppelt"})
            return
        try:
            message = execute_action(str(obj.get("action", "")), obj, local=self.local())
            self.respond(200, {"ok": True, "message": message})
        except (ValueError, OSError, subprocess.SubprocessError) as exc:
            self.respond(400, {"error": str(exc)})


def main():
    global PORT
    parser = argparse.ArgumentParser(description="NovaOS 4.1.1 Web-Oberfläche und Fernbedienung")
    parser.add_argument("--port", type=int, default=PORT)
    parser.add_argument("--localhost", action="store_true", help="LAN-Fernbedienung ausschalten")
    args = parser.parse_args()
    PORT = args.port
    if os.name != "nt":
        threading.Thread(target=ir_loop, name="novaos-ir", daemon=True).start()
        threading.Thread(target=lg_event_loop, args=(lg_event, LAST_LG), name="novaos-lg", daemon=True).start()
    addr = "127.0.0.1" if args.localhost else "0.0.0.0"
    server = ThreadingHTTPServer((addr, PORT), NovaHandler)
    server.daemon_threads = True
    print(f"NovaOS 4.1.1 startet: http://127.0.0.1:{PORT}  |  Handy: http://{available_ip()}:{PORT}/remote", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("NovaOS beendet")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
