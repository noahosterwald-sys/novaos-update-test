#!/usr/bin/env bash
# Nur lesende Hardwarediagnose, aendert keine Einstellungen.
echo '=== NovaOS HDMI & Audio Diagnose ==='
printf '\nKernel: '; uname -r
printf '\nGrafikkarten/HDMI:\n'; lspci 2>/dev/null | grep -Ei 'audio|vga|display' || true
printf '\nAusgaenge (PipeWire/PulseAudio):\n'; pactl list short sinks 2>&1 || true
printf '\nProfile/Karten:\n'; pactl list short cards 2>&1 || true
printf '\nALSA Wiedergabegeraete:\n'; aplay -l 2>&1 || true
printf '\nMonitore:\n'; xrandr --query 2>&1 | grep ' connected' || true
