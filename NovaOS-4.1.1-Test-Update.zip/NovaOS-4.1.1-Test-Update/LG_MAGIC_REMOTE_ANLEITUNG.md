# LG Magic Remote MR20 unter NovaOS 4.1

Deine Fernbedienung wurde in Debian als `LGE MR20` mit Bluetooth-Kennung `v000Fp3412` erkannt. Ein LG-Magic-Treiber stellte `LG Magic Remote` und `LG Magic Remote IMU` bereit; Tastendrücke und Bewegungssignale wurden bereits über Linux beobachtet. Das ist die Basis für die automatische Integration.

## Was NovaOS 4.1 automatisiert

- Beim Start nach gekoppelter MR20 suchen.
- DKMS-Treiber installieren, wenn passende Kernel-Headers und Internet bzw. bereits heruntergeladene Quellcodes verfügbar sind.
- Existierende Kalibrierungsdaten aus `~/lg-magic` wiederverwenden (falls gefunden und gültig).
- `lg_magic` für zukünftige Systemstarts aktivieren.
- Sondertasten einem NovaOS-Befehl zuordnen und weitere Tasten anlernen.
- Die bereits vom Kernel gelieferten Pfeile, Mausklicks und Bewegungsdaten unangetastet lassen.

## Vorbelegte Tasten

| LG-Taste (Linux-Code) | NovaOS-Aktion |
|---|---|
| Lauter `KEY_VOLUMEUP` | Lautstärke + |
| Leiser `KEY_VOLUMEDOWN` | Lautstärke − |
| Stumm `KEY_MUTE` | Stummschalten |
| Home `KEY_HOMEPAGE` | Startseite |
| Zurück `KEY_BACK` | Zurück |
| Menü / Einstellungen `KEY_MENU`, `KEY_CONFIG`, `KEY_SETUP` | Einstellungen |
| Ein/Aus `KEY_POWER` | Ausschaltmenü mit Bestätigung |
| Play/Pause `KEY_PLAYPAUSE` | Medienwiedergabe |
| Vorheriger/nächster Song | Mediensteuerung |

**Hinweis:** Welche dieser Codes tatsächlich ausgegeben werden, hängt von Firmware und Treiberversion ab. Xfce kann manche Tasten ebenfalls abfangen; Doppelaktionen müssen am echten Lenovo überprüft werden. Falls die Fernbedienung nur bestimmte Tasten unterstützt, diese über „LG anlernen“ selbst zuordnen.

## Manuelle Einrichtung (falls automatische Einrichtung nicht abgeschlossen)

In NovaOS: `⚙ → Fernbedienung → LG automatisch einrichten`.
Das Terminal zeigt den Fortschritt und eventuelle Fehler, gegebenenfalls mit Administratorpasswort. Bei einer frischen Kopplung kann ein Neustart nötig sein. Das externe Originalprojekt ist [brainrom/lg-magic](https://github.com/brainrom/lg-magic), Lizenz GPLv2.

**Es wird keine neue Kalibrierung erfunden.** Falls alle alten Kalibrierungsdateien fehlen, sind neue Sensor-Aufnahmen erforderlich. Ohne sie kann die Luftmaus trotz erfolgreicher Bluetooth-Kopplung unpräzise bleiben.

### Diagnose

```bash
bluetoothctl devices
lsmod | grep lg_magic
sudo systemctl status novaos-lg-setup.service --no-pager
sudo journalctl -u novaos-lg-setup.service -n 50 --no-pager
```

Sollte der Power-Knopf ohne den NovaOS-Dialog direkt herunterfahren, liegt die Behandlung des `KEY_POWER`-Signals durch Linux/Logind oder die Desktop-Umgebung vor. Die bereitgestellte udev-Regel versucht, `power-switch` **nur für die LG-Fernbedienung** zu deaktivieren; die Wirkung muss auf der echten Hardware kontrolliert werden.
