@echo off
call "%~dp0NOVAOS_4_1_USB_STARTEN.bat"
