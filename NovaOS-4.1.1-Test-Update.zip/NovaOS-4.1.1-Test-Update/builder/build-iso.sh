#!/usr/bin/env bash
# NovaOS 4.1: baut ein Debian 13 Hybrid-Live-ISO mit vorinstalliertem NovaOS.
# Nur auf Debian 13 amd64 mit Internet. Erstellt KEINEN USB-Stick, loescht keine Festplatte.
set -Eeuo pipefail
trap 'echo "[NovaOS] FEHLER in Zeile $LINENO. Buildprotokoll bitte pruefen." >&2' ERR
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
[[ $EUID == 0 ]] || { echo 'Mit sudo starten: sudo bash builder/build-iso.sh' >&2; exit 1; }
[[ -f /etc/debian_version ]] || { echo 'Nur Debian 13 wird unterstuetzt.' >&2; exit 1; }
. /etc/os-release
[[ "${VERSION_CODENAME:-}" == trixie ]] || { echo 'Debian 13 (trixie) erforderlich.' >&2; exit 1; }
[[ "$(uname -m)" == x86_64 ]] || { echo '64-Bit-Rechner erforderlich.' >&2; exit 1; }
[[ -f "$ROOT/backend/server.py" ]] || { echo 'NovaOS-Quellen fehlen.' >&2; exit 1; }
BUILD_DIR="${NOVAOS_BUILD_DIR:-$ROOT/_iso-build}"
mkdir -p "$BUILD_DIR"
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y live-build debootstrap squashfs-tools xorriso isolinux syslinux-common \
  syslinux-utils grub-pc-bin grub-efi-amd64-bin mtools dosfstools ca-certificates
cd "$BUILD_DIR"
# Always remove previous live-build settings before constructing a new version.
# BUILD_DIR lives on ext4 inside WSL; never remove user-selected disk contents.
if [[ -f config/common || -d .build || -e auto/config ]]; then lb clean --purge || true; fi
rm -rf config auto
# Der Buildordner muss auf einem Linux-Dateisystem liegen, nicht auf /mnt/c in WSL.
lb config --mode debian --architectures amd64 --distribution trixie \
 --binary-image iso-hybrid --debian-installer none \
 --archive-areas 'main contrib non-free-firmware' \
 --bootappend-live 'boot=live components locales=de_DE.UTF-8 keyboard-layouts=de timezone=Europe/Berlin hostname=novaos username=user' \
 --iso-application 'NovaOS 4.1 / Debian 13' \
 --iso-publisher 'NovaOS Projekt' --iso-volume 'NOVAOS_41'
mkdir -p config/package-lists config/includes.chroot/opt/novaos config/hooks/live config/archives
# Debian 13 provides scrcpy in trixie-backports, not in the base trixie repository.
# This Debian-signed repository is needed during ISO creation and for future updates.
printf '%s\n' 'deb http://deb.debian.org/debian trixie-backports main contrib non-free-firmware' \
  > config/archives/trixie-backports.list.chroot
cp config/archives/trixie-backports.list.chroot config/archives/trixie-backports.list.binary
cp "$HERE/novaos.list.chroot" config/package-lists/novaos.list.chroot
cp -a "$ROOT"/{backend,web,installer,arduino,assets,diagnose,android-option,lg-remote,updater,VERSION,README.md,INSTALLATION.md,STATUS_UND_GRENZEN.md} config/includes.chroot/opt/novaos/
cat > config/hooks/live/9999-novaos.hook.chroot <<'HOOK'
#!/bin/sh
set -eu
sh /opt/novaos/installer/configure-system.sh
HOOK
chmod +x config/hooks/live/9999-novaos.hook.chroot
printf '\n[NovaOS] Baue Live-ISO. Download kann lange dauern ...\n'
lb build
ISO="$(find "$BUILD_DIR" -maxdepth 1 -type f -name '*.iso' -print -quit)"
[[ -n "$ISO" ]] || { echo 'Kein ISO erstellt.' >&2; exit 1; }
OUT="$ROOT/NovaOS-4.1-amd64.iso"
cp -f "$ISO" "$OUT"
(cd "$ROOT" && sha256sum "$(basename "$OUT")" > "$(basename "$OUT").sha256")
echo "FERTIG: $OUT"
