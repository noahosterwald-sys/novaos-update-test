#!/usr/bin/env bash
# Wird vom Windows-Assistenten via WSL2 Debian als root aufgerufen.
# Quellverzeichnis liegt auf /mnt/c; Build muss auf ext4 /root liegen.
set -Eeuo pipefail
SRC="${1:?Windows-Quellordner fehlt}"
[[ -f "$SRC/backend/server.py" ]] || { echo 'NovaOS-Dateien nicht gefunden.'; exit 1; }
BUILDHOME=/root/novaos-4.1-build
# Prevent stale source files from previous versions leaking into the new ISO.
rm -rf "$BUILDHOME/source"
mkdir -p "$BUILDHOME/source"
# New, deterministic snapshot of the source.
cp -a "$SRC"/backend "$SRC"/web "$SRC"/installer "$SRC"/arduino "$SRC"/assets "$SRC"/diagnose "$SRC"/android-option "$SRC"/lg-remote "$SRC"/updater "$SRC"/VERSION "$SRC"/builder "$SRC"/README.md "$SRC"/INSTALLATION.md "$SRC"/STATUS_UND_GRENZEN.md "$BUILDHOME/source/"
cd "$BUILDHOME/source"
export NOVAOS_BUILD_DIR="$BUILDHOME/work"
bash builder/build-iso.sh
cp -f "$BUILDHOME/source/NovaOS-4.1-amd64.iso" "$SRC/"
cp -f "$BUILDHOME/source/NovaOS-4.1-amd64.iso.sha256" "$SRC/"
echo "ISO liegt jetzt im Windows-Ordner: $SRC/NovaOS-4.1-amd64.iso"
